package com.dtb.member.activemq;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.Session;

import org.apache.activemq.command.ActiveMQTextMessage;
import org.springframework.jms.listener.SessionAwareMessageListener;
import org.springframework.stereotype.Component;

@Component("consumerMessageListener")
public class TopicConsumerMessageListener implements SessionAwareMessageListener<ActiveMQTextMessage>{

	@Override
	public void onMessage(ActiveMQTextMessage message, Session session) throws JMSException {
		try {
			System.out.println("consumerMessageListener接收到消息：" + message.getText());
			if (Math.random()>0.5) {
				throw new Exception();//回滚测试
			}
		} catch (Exception e) {
			session.rollback();
			e.printStackTrace();
		}
		session.commit();
	}
	
}
