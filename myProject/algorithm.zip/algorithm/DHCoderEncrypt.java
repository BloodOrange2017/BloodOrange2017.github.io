package com.dtb.algorithm;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.KeyAgreement;
import javax.crypto.SecretKey;
import javax.crypto.interfaces.DHPrivateKey;
import javax.crypto.interfaces.DHPublicKey;
import javax.crypto.spec.DHParameterSpec;

import com.sun.org.apache.xml.internal.security.utils.Base64;
/**
 * 非对称加密算法 
 * @author xuecheng
 *
 */
public class DHCoderEncrypt {
	/** 
     * 非对称加密密钥算法 
     */  
    private static final String KEY_ALGORITHM = "DH";  
	/** 
     * 密钥长度 
     */  
    private static final int KEY_SIZE = 1024;  
    /** 
     * 本地密钥算法，即对称加密密钥算法 
     * 可选DES、DESede或者AES 
     */  
    private static final String SELECT_ALGORITHM = "AES";
	/** 
     * 初始化甲方密钥 
     * @return Map 甲方密钥Map 
	 * @throws Exception 
     */  
    public  Map<String, Object> initSendKey() throws Exception{  
        //实例化密钥对生成器  
        KeyPairGenerator keyPairGenerator = null;
		keyPairGenerator = KeyPairGenerator.getInstance(KEY_ALGORITHM);
		//keyPairGenerator = keyPairGenerator.getInstance(algorithm)
        //初始化密钥对生成器  
        keyPairGenerator.initialize(KEY_SIZE);  
        //生成密钥对  
        KeyPair keyPair = keyPairGenerator.generateKeyPair();  
        
        //甲方公钥  
        DHPublicKey publicKey = (DHPublicKey)keyPair.getPublic();  
        //甲方私钥  
        DHPrivateKey privateKey = (DHPrivateKey)keyPair.getPrivate();  
        //将密钥对存储在Map中  
        Map<String, Object> keyMap = new HashMap<String, Object>(2);  
        keyMap.put("publicKey", publicKey);  
        keyMap.put("privateKey", privateKey);  
        return keyMap;  
    }
    
    /** 
     * 初始化乙方密钥 
     * @param key 甲方公钥 
     * @return Map 乙方密钥Map 
     * @throws Exception 
     */  
    public  Map<String, Object> initToKey(byte[] key) throws Exception{  
        //解析甲方公钥  
        //转换公钥材料  
        X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(key);  
        //实例化密钥工厂  
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);  
        //产生公钥  
        PublicKey pubKey = keyFactory.generatePublic(x509KeySpec);  
        //由甲方公钥构建乙方密钥  
        DHParameterSpec dhParameterSpec = ((DHPublicKey)pubKey).getParams();  
        //实例化密钥对生成器  
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance(KEY_ALGORITHM);  
        //初始化密钥对生成器  
        keyPairGenerator.initialize(dhParameterSpec);  
        //产生密钥对  
        KeyPair keyPair = keyPairGenerator.generateKeyPair();  
        //乙方公钥  
        DHPublicKey publicKey = (DHPublicKey) keyPair.getPublic();  
        //乙方私约  
        DHPrivateKey privateKey = (DHPrivateKey) keyPair.getPrivate();  
        //将密钥对存储在Map中  
        Map<String, Object> keyMap = new HashMap<String, Object>(2);  
        keyMap.put("publicKey", publicKey);  
        keyMap.put("privateKey", privateKey);  
        return keyMap;  
    }  
    
    /** 
     * 构建密钥 
     * @param publicKey 公钥 
     * @param privateKey 私钥 
     * @return String 本地密钥 
     * @throws Exception 
     */  
    public  String getSecretKey(byte[] publicKey, byte[] privateKey) throws Exception{  
        //实例化密钥工厂  
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);  
        //初始化公钥  
        //密钥材料转换  
        X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(publicKey);  
        //产生公钥  
        PublicKey pubKey = keyFactory.generatePublic(x509KeySpec);  
        //初始化私钥  
        //密钥材料转换  
        PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(privateKey);  
        //产生私钥  
        PrivateKey priKey = keyFactory.generatePrivate(pkcs8KeySpec);  
        //实例化  
        KeyAgreement keyAgree = KeyAgreement.getInstance(keyFactory.getAlgorithm());  
        //初始化  
        keyAgree.init(priKey);  
        keyAgree.doPhase(pubKey, true);  
        //生成本地密钥  
        SecretKey secretKey = keyAgree.generateSecret(SELECT_ALGORITHM);  
        return Base64.encode(secretKey.getEncoded());  
    }  
    
    public static void main(String[] args) throws Exception {
    	DHCoderEncrypt dhCoderEncrypt = new DHCoderEncrypt();
    	Map<String, Object> initSendKey = dhCoderEncrypt.initSendKey();
    	DHPublicKey publicKeya = (DHPublicKey) initSendKey.get("publicKey");
    	DHPrivateKey privateKeya = (DHPrivateKey) initSendKey.get("privateKey");
    	Map<String, Object> initToKey = dhCoderEncrypt.initToKey(publicKeya.getEncoded());
    	DHPublicKey publicKeyb = (DHPublicKey) initToKey.get("publicKey");
    	DHPrivateKey privateKeyb = (DHPrivateKey) initToKey.get("privateKey");
    	String Keya = dhCoderEncrypt.getSecretKey(publicKeya.getEncoded(), privateKeyb.getEncoded());
    	String keyb = dhCoderEncrypt.getSecretKey(publicKeyb.getEncoded(), privateKeya.getEncoded());
    	System.out.println(Keya);
    	System.out.println(keyb);
    	String encrypt = DESUtil.encrypt("大家好我叫XHC", Keya);
    	String decrypt = DESUtil.decrypt(encrypt, keyb);
    	System.out.println(decrypt);
	}
    
}
