package com.dtb.member.test;

import java.security.InvalidAlgorithmParameterException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.SecretKey;
import javax.crypto.interfaces.DHPrivateKey;
import javax.crypto.interfaces.DHPublicKey;
import javax.crypto.spec.DHParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import com.sun.org.apache.xml.internal.security.utils.Base64;
/**
 * 
 * @author xuecheng
 *
 */
public class DHCoderEncrypt {
	/** 
     * 非对称加密密钥算法 
     */  
    private static final String KEY_ALGORITHM = "DH";  
	/** 
     * 密钥长度 
     */  
    private static final int KEY_SIZE = 1024;  
    /** 
     * 本地密钥算法，即对称加密密钥算法 
     * 可选DES、DESede或者AES 
     */  
    private static final String SELECT_ALGORITHM = "AES";
	/**
	 * 公钥
	 */
    private DHPublicKey publicKey;
	/**
	 * 密钥
	 */
    private DHPrivateKey privateKey;
	
	/** 
     * 初始化甲方密钥 构造方法
	 * @throws NoSuchAlgorithmException 
     */  
    public DHCoderEncrypt() throws NoSuchAlgorithmException {
    	//this is init method
    	//实例化密钥对生成器  
        KeyPairGenerator keyPairGenerator = null;
		keyPairGenerator = KeyPairGenerator.getInstance(KEY_ALGORITHM);
        //初始化密钥对生成器  
        keyPairGenerator.initialize(KEY_SIZE);  
        //生成密钥对  
        KeyPair keyPair = keyPairGenerator.generateKeyPair();  
        //甲方公钥  
        DHPublicKey publicKey = (DHPublicKey)keyPair.getPublic();  
        //甲方私钥  
        DHPrivateKey privateKey = (DHPrivateKey)keyPair.getPrivate();  
        //将密钥对存储在entity中  
        this.publicKey=publicKey;
        this.privateKey=privateKey;
	}
    /** 
     * 初始化乙方密钥 
     * purblicKey 承接构建出来的公钥 密钥
     * @param key 甲方公钥 
     * @throws NoSuchAlgorithmException 
     * @throws InvalidKeySpecException 
     * @throws InvalidAlgorithmParameterException 
     */  
    public DHCoderEncrypt(byte[] key) throws NoSuchAlgorithmException, InvalidKeySpecException, InvalidAlgorithmParameterException {
    	//解析甲方公钥  
        //转换公钥材料  
        X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(key);  
        //实例化密钥工厂  
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);  
        //产生公钥  
        PublicKey pubKey = keyFactory.generatePublic(x509KeySpec);  
        //由甲方公钥构建乙方密钥  
        DHParameterSpec dhParameterSpec = ((DHPublicKey)pubKey).getParams();  
        //实例化密钥对生成器  
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance(KEY_ALGORITHM);  
        //初始化密钥对生成器  
        keyPairGenerator.initialize(dhParameterSpec);  
        //产生密钥对  
        KeyPair keyPair = keyPairGenerator.generateKeyPair();  
        //乙方公钥  
        DHPublicKey publicKey = (DHPublicKey) keyPair.getPublic();  
        //乙方私约  
        DHPrivateKey privateKey = (DHPrivateKey) keyPair.getPrivate();  
        //将密钥对存储在类中  
        this.publicKey=publicKey;
        this.privateKey=privateKey;
	}
    
    /** 
     * 构建密钥 
     * 根据非对称RSA加密算法机制,甲.publicKey-算法-乙.privateKey 与 乙.publicKey-算法-甲.privateKey 其结果相同
     * 因此可以获得同一个本地密匙，用于数据加密
     * @param publicKey 公钥 
     * @param privateKey 私钥 
     * @return byte[] 本地密钥 
     * @throws Exception 
     */  
    public static String getSecretKey(byte[] publicKey,byte[] privateKey) throws Exception{  
        //实例化密钥工厂  
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);  
        //初始化公钥  
        //密钥材料转换  
        X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(publicKey);  
        //产生公钥  
        PublicKey pubKey = keyFactory.generatePublic(x509KeySpec);  
        //初始化私钥  
        //密钥材料转换  
        PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(privateKey);  
        //产生私钥  
        PrivateKey priKey = keyFactory.generatePrivate(pkcs8KeySpec);  
        //实例化  
        KeyAgreement keyAgree = KeyAgreement.getInstance(keyFactory.getAlgorithm());  
        //初始化  
        keyAgree.init(priKey);  
        keyAgree.doPhase(pubKey, true);  
        //生成本地密钥  
        SecretKey secretKey = keyAgree.generateSecret(SELECT_ALGORITHM);  
        String localSecretKey = Base64.encode(secretKey.getEncoded());
        return localSecretKey;  
    }  
    /**
     * 获取公钥
     * @return
     */
    public byte [] getPublicKey() {
		return publicKey.getEncoded();
	}
    /**
     * 获取秘钥
     * @return
     */
	public byte [] getPrivateKey() {
		return privateKey.getEncoded();
	}
    public static void main(String[] args) throws Exception {
		DHCoderEncrypt dhCoderEncryptA = new DHCoderEncrypt();
		DHCoderEncrypt dhCoderEncryptB = new DHCoderEncrypt(dhCoderEncryptA.getPublicKey());
		String secretKey = DHCoderEncrypt.getSecretKey(dhCoderEncryptA.getPublicKey(), dhCoderEncryptB.getPrivateKey());
		String secretKey2 = DHCoderEncrypt.getSecretKey(dhCoderEncryptB.getPublicKey(), dhCoderEncryptA.getPrivateKey());
		System.out.println(secretKey);
		System.out.println(secretKey2);
	}
}
