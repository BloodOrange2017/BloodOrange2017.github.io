package bhz.service;

import bhz.entity.Simple;

public interface SimpleService {
	
	public String sayHello(String name);

	public Simple getSimple();
}
