package com.dtb.activemq;


import javax.jms.JMSException;
import javax.jms.Session;

import org.apache.activemq.command.ActiveMQTextMessage;
import org.springframework.jms.listener.SessionAwareMessageListener;
import org.springframework.stereotype.Component;

/**
 * Description: <br/>
 * 消息队列监听器
 * 
 * @author xuecheng
 * @date 2016年4月25日 上午10:32:14
 **/
@Component("queueReceiver1")
public class QueueReceiver1 implements SessionAwareMessageListener<ActiveMQTextMessage>{

	public void onMessage(ActiveMQTextMessage message, Session session) throws JMSException {
		try {
			System.out.println("QueueReceiver1接收到消息：" + message.getText());
			if (Math.random()>0.5) {
				throw new Exception();//回滚测试
			}
		} catch (Exception e) {
			session.rollback();
			e.printStackTrace();
		}
		session.commit();
	}

}
