package com.dtb.service;

import com.dtb.entity.User;

public interface DemoUserService {
	User selectUserByMoblie(String Mobile);

	int updateUser(User selectUserByMoblie);

	void Transaction() throws Exception;
}
