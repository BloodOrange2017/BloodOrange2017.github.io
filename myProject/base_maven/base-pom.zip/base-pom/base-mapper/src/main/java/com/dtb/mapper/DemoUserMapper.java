package com.dtb.mapper;

import com.dtb.entity.User;

public interface DemoUserMapper {
	User selectUserByMoblie(String mobile);

	int updateUser(User user);
}
