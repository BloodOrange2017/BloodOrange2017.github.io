package com.base.redis;

public enum RedisConnectionEnum {
	/**
	 * redis缓存分库类型：
		0.固定值,用户信息,系统级设置（system_value、特殊账户、内部员工等）
		1.常规活动，业务规则配置（抽奖、签到等）
		2.临时活动（周年庆，升级战纪等）
		3.实时计算结果（五档报价，交易数据）
		4.系统级缓存（短信验证码，防二次提交，登录）
		5.数据采集，统计类（访问次数等）
	 */
    SYSTEM_VALUE(0),COMMON_ACTIVITY_CONFIG(1), TEMP_ACTIVITY_CONFIG(2),INSTANTLY_REFRESH(3),SYSTEM_CACHE(4),STATISTICS(5);  
    // 成员变量  
    private int dbNum;
    // 构造方法  
    private RedisConnectionEnum(int dbNum) {  
        this.dbNum = dbNum;
    }
    @Override
    public String toString() {
    	return ""+dbNum;
    }
	public int getDbNum() {
		return dbNum;
	}
	public void setDbNum(int dbNum) {
		this.dbNum = dbNum;
	}  
    
}
