package com.base.mapper
;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface DemoMapper {
	//@Select("select USER_NAME from t_user where user_id = #{userId}")
	String getUserNameByUserId(@Param("userId")Integer userId);
	//@Update("update t_user set USER_NAME = #{name} where user_id = #{userId}")
	int updataUserName(@Param("name")String name, @Param("userId")Integer userId);

}
