package com.base.service;

public interface DemoService {

	String getUserNameByUserId(Integer userId);
	
	int updataUserName(String name,Integer userId);
}
