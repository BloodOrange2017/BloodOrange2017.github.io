package com.base.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.base.entity.ResultData;


@Controller
@RequestMapping("/page")
public class DemoPageController {
	@RequestMapping("/demo.html")
	public String name(HttpServletRequest request) {
		request.setAttribute("descrip", "abcdefghijklmnopq123");
		return "/demopage";
	}
	@RequestMapping("/feedback.html")
	@ResponseBody
	public ResultData feedback(@RequestParam(value="files",required=false)MultipartFile files[],Integer feedbackType,byte[] remark,HttpServletRequest request,HttpServletResponse response) throws IOException{
		ResultData resultData = new ResultData();
		for (int i = 0; i < files.length; i++) {  
			MultipartFile commonsMultipartFile = files[i];
	    	System.out.println(commonsMultipartFile.getInputStream());
		}
		return resultData;
	}
}
