package com.base.controller;

import javax.annotation.Resource;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.base.redis.RedisConnectionEnum;
import com.base.redis.RedisOperate;
import com.base.service.DemoService;

@RestController
@RequestMapping("/demo")
public class DemoController {
	@Resource
	private DemoService demoService;
	@Resource
	private RedisOperate redisOperate;
	@RequestMapping(value="/one/{userId}", method = RequestMethod.GET)
	public String name(@PathVariable("userId") Integer userId) {
		String string = redisOperate.get("config:4S_SERVER_URL", RedisConnectionEnum.SYSTEM_VALUE);
		System.out.println(string);
		String userName = demoService.getUserNameByUserId(userId);
		return userName+""+string.trim();
	}
	@RequestMapping(value="/updataUser/{userId}/{name}", method = RequestMethod.GET)
	public int updataUser(@PathVariable("userId") Integer userId,@PathVariable("name") String name) {
		return demoService.updataUserName(name, userId);
	}
}
