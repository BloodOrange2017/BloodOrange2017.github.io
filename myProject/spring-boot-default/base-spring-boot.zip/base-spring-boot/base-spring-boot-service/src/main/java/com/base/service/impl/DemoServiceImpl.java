package com.base.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.base.dataresource.TargetDataSource;
import com.base.mapper.DemoMapper;
import com.base.service.DemoService;
@Service
public class DemoServiceImpl implements DemoService{
	@Resource
	private DemoMapper demoMapper;
	//@TargetDataSource(name="onlyread")
	@Override
	public String getUserNameByUserId(Integer userId) {
		return demoMapper.getUserNameByUserId(userId);
	}

	@Override
	@Transactional
	public int updataUserName(String name, Integer userId) {
		return demoMapper.updataUserName(name, userId);
	}

}
