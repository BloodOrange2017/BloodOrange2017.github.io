package com.base.redis;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Component;

@Component
public class RedisOperate {

	@Resource(name="stringRedisTemplate")
    private StringRedisTemplate stringRedisTemplate0;
	@Resource(name="stringRedisTemplate")
	private StringRedisTemplate stringRedisTemplate1;
	@Resource(name="stringRedisTemplate")
	private StringRedisTemplate stringRedisTemplate2;
	@Resource(name="stringRedisTemplate")
	private StringRedisTemplate stringRedisTemplate3;
	@Resource(name="stringRedisTemplate")
	private StringRedisTemplate stringRedisTemplate4;
	@Resource(name="stringRedisTemplate")
	private StringRedisTemplate stringRedisTemplate5;
    @Autowired
    private JedisConnectionFactory jedisConnFactory;
    @Autowired
    private JedisConnectionFactory jedisConnFactory1;
    @Autowired
    private JedisConnectionFactory jedisConnFactory2;
    @Autowired
    private JedisConnectionFactory jedisConnFactory3;
    @Autowired
    private JedisConnectionFactory jedisConnFactory4;
    @Autowired
    private JedisConnectionFactory jedisConnFactory5;
    private boolean isInit = false;
    private StringRedisTemplate choseConnection(RedisConnectionEnum redisEnum){
    	if (!isInit) {
    		stringRedisTemplate0.setConnectionFactory(jedisConnFactory);
        	stringRedisTemplate1.setConnectionFactory(jedisConnFactory1);
        	stringRedisTemplate2.setConnectionFactory(jedisConnFactory2);
        	stringRedisTemplate3.setConnectionFactory(jedisConnFactory3);
        	stringRedisTemplate4.setConnectionFactory(jedisConnFactory4);
        	stringRedisTemplate5.setConnectionFactory(jedisConnFactory5);
        	isInit = true;
		}
    	switch (redisEnum.getDbNum()) {
		case 0:
			return stringRedisTemplate0;
		case 1:
			return stringRedisTemplate1;
		case 2:
			return stringRedisTemplate2;
		case 3:
			return stringRedisTemplate3;
		case 4:
			return stringRedisTemplate4;
		case 5:
			return stringRedisTemplate5;
		default:
			return stringRedisTemplate0;
		}
    }
    public String getString(String key,RedisConnectionEnum redisEnum) {
    	StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
        return stringRedisTemplate.opsForValue().get(key);
    }

    public String hget(String key, String field,RedisConnectionEnum redisEnum) {
    	StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
        HashOperations<String, String, String> opsForHash = stringRedisTemplate.opsForHash();
        return opsForHash.get(key, field);
    }

    public Map<String, String> hgetAll(String key,RedisConnectionEnum redisEnum) {
    	StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
        HashOperations<String, String, String> opsForHash = stringRedisTemplate.opsForHash();
        return opsForHash.entries(key);
    }

    /**
     * 根据key，将哈希表hashMap存到redis中。
     * 有则覆盖，无则插入
     * @param key
     * @param hashMap
     */
    public void hset(String key, Map<String, String> hashMap,RedisConnectionEnum redisEnum) {
    	StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
    	//把去空的hashMap再存到red is中
        HashOperations<String, String, String> opsForHash = stringRedisTemplate.opsForHash();
        opsForHash.putAll(key, hashMap);
    }
    
    /**
     * 将哈希表 key 中的域 field 的值设为 value 。
     * 如果 key 不存在，一个新的哈希表被创建并进行 HSET 操作。
     * 如果域 field(hashKey) 已经存在于哈希表中，旧值将被覆盖。
     * @param key
     * @param hashKey
     * @param value
     */
    public void hset(String key,String hashKey,String value,RedisConnectionEnum redisEnum) {
    	StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
    	 HashOperations<String, String, String> opsForHash = stringRedisTemplate.opsForHash();
         opsForHash.put(key, hashKey, value);
    }

    public void expire(String key, long timeout, TimeUnit unit,RedisConnectionEnum redisEnum) {
    	StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
        stringRedisTemplate.expire(key, timeout, unit);
    }


    /**
     * 根据keys批量删除
     * @param keys
     */
    public void delete(List<String> keys,RedisConnectionEnum redisEnum) {
    	StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
        stringRedisTemplate.delete(keys);
    }

    
    /**
     * 检查给定 key 是否存在。
     * @param key 
     * @return  存在返回true
     */
    public boolean exists(String key,RedisConnectionEnum redisEnum){
    	StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
    	return stringRedisTemplate.hasKey(key);
    }
    
    /**
     * 向redis存入key和value
	 * 如果key已经存在 则覆盖
     * @param key
     * @param value
     */
    public void set(String key,String value,RedisConnectionEnum redisEnum){
    	StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
    	ValueOperations<String, String> opsForValue = stringRedisTemplate.opsForValue();
    	opsForValue.set(key, value);
    }
    
    /**
     * 如果 key 已经存在并且是一个字符串， APPEND 命令将 value 追加到 key 原来的值的末尾。
     * 如果 key 不存在， APPEND 就简单地将给定 key 设为 value ，就像执行 SET key value 一样。
     * @param key
     * @param value
     */
    public void append(String key,String value,RedisConnectionEnum redisEnum){
    	StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
    	ValueOperations<String, String> opsForValue = stringRedisTemplate.opsForValue();
    	opsForValue.append(key, value);
    }
    
    
    /**
	 * 通过key向list头部添加字符串
	 * @param key
	 * @param strs 可以使一个string 也可以使string数组
	 * @return 返回list的value个数
	 */
    public Long lpush(String key ,RedisConnectionEnum redisEnum,String...strs){
    	StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
    	ListOperations<String, String> opsForList = stringRedisTemplate.opsForList();
    	long res = 0;
    	int len = strs.length;
    	if (len > 0) {
			for(int i = 0;i < len;i++){
				res += (opsForList.leftPush(key, strs[i])).longValue();
			}
		}
    	return res;
    }
    
    /**
     * 通过key向list尾部添加字符串
     * @param key
     * @param strs 可以使一个string 也可以使string数组
     * @return 返回list的value个数
     */
    public Long rpush(String key,RedisConnectionEnum redisEnum, String...strs){
    	StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
    	ListOperations<String, String> opsForList = stringRedisTemplate.opsForList();
    	long res = 0;
    	int len = strs.length;
    	if (len > 0) {
    		for(int i = 0;i < len;i++){
    			res += (opsForList.rightPush(key, strs[i])).longValue();
    		}
    	}
    	return res;
    }
    
    /**
     * 通过key设置list指定下标位置的value
	 * 如果下标超过list里面value的个数则返回false
	 * @param key 
	 * @param index 从0开始
	 * @param value
	 * @return 成功返回true
     */
    public boolean lset(String key, Long index, String value,RedisConnectionEnum redisEnum){
    	StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
    	ListOperations<String, String> opsForList = stringRedisTemplate.opsForList();
    	Long size = opsForList.size(key);
    	//先判断index下标大小是否超过list的大小
    	if (index < size) {
    		opsForList.set(key, index, value);
    		return true;
		}
    	return false;
    }
    
    /**
	 * 通过key获取list指定下标位置的value
	 * 如果start 为 0 end 为 -1 则返回全部的list中的value
	 * @param key 
	 * @param start
	 * @param end
	 * @return
	 */
	public List<String> lrange(String key, long start, long end,RedisConnectionEnum redisEnum){
		StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
		ListOperations<String, String> opsForList = stringRedisTemplate.opsForList();
		return opsForList.range(key, start, end);
	}
	/**
	 * 通过key获取list的size
	 * 
	 * @param key 
	 * @return
	 */
	public Long lsize(String key,RedisConnectionEnum redisEnum){
		StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
		ListOperations<String, String> opsForList = stringRedisTemplate.opsForList();
		return opsForList.size(key);
	}
	
	/**
	 * <p>通过key从对应的list中删除指定的count个 和 value相同的元素</p>
	 * @param key 
	 * @param count 当count为0时删除全部
	 * count > 0 : 从表头开始向表尾搜索，移除与 value 相等的元素，数量为 count 。
	 * count < 0 : 从表尾开始向表头搜索，移除与 value 相等的元素，数量为 count 的绝对值。
	 * count = 0 : 移除表中所有与 value 相等的值。
	 * @param value 
	 * @return 返回被删除的个数
	 */
	public Long lrem(String key,long count,String value,RedisConnectionEnum redisEnum){
		StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
		ListOperations<String, String> opsForList = stringRedisTemplate.opsForList();
		return opsForList.remove(key, count, value);
	}
	
	/**
	 * 通过key从list尾部删除一个value,并返回该元素
	 * @param key
	 * @return
	 */
	public String rpop(String key,RedisConnectionEnum redisEnum){
		StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
		ListOperations<String, String> opsForList = stringRedisTemplate.opsForList();
		return opsForList.rightPop(key);
	}
	
	/**
	 * 通过key从list头部删除一个value,并返回该元素
	 * @param key
	 * @return
	 */
	public String lpop(String key,RedisConnectionEnum redisEnum){
		StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
		ListOperations<String, String> opsForList = stringRedisTemplate.opsForList();
		return opsForList.leftPop(key);
	}
	
	/**
	 * 通过key向zset中添加value,score,其中score就是用来排序的(权重)
	 * 如果该value已经存在则根据score更新元素
	 * @param key
	 * @param scoreMembers 
	 * @return
	 */
	public boolean zadd(String key, String value, double score,RedisConnectionEnum redisEnum){
		StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
		ZSetOperations<String, String> opsForZSet = stringRedisTemplate.opsForZSet();
		return opsForZSet.add(key, value, score);
	}
	
	/**
	 * 通过key返回指定score区间内zset中的value
	 * @param key 
	 * @param max 
	 * @param min 
	 * @return
	 */
	public Set<String> zrangebyScore(String key, double min, double max,RedisConnectionEnum redisEnum){
		StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
		ZSetOperations<String, String> opsForZSet = stringRedisTemplate.opsForZSet();
		return opsForZSet.rangeByScore(key, min, max);
	}
	
	/**
	 * 通过key将获取位置从start到end中zset的value
	 * socre从大到小排序
	 * @param key 
	 * @param max  
	 * @param min 
	 * @return
	 */
	public Set<String> zrevrange(String key, long start, long end,RedisConnectionEnum redisEnum){
		StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
		ZSetOperations<String, String> opsForZSet = stringRedisTemplate.opsForZSet();
		return opsForZSet.reverseRange(key, start, end);
	}
	
	/**
	 * 通过key将获取score从start到end中zset的value
	 * score从大到小排序
	 * @param key 键
	 * @param min 降序排序的起始权重
	 * @param max 降序排序的结束权重
	 * @return
	 */
	public Set<String> zrevrangeByScore(String key, double min, double max,RedisConnectionEnum redisEnum) {
		StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
		ZSetOperations<String, String> opsForZSet = stringRedisTemplate.opsForZSet();
		return opsForZSet.reverseRangeByScore(key, min, max);
	}
	
	/**
	 * 通过key获取zset中value的score值
	 * @param key
	 * @param member
	 * @return
	 */
	public Double zscore(String key,String member,RedisConnectionEnum redisEnum){
		StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
		ZSetOperations<String, String> opsForZSet = stringRedisTemplate.opsForZSet();
		return opsForZSet.score(key, member);
	}
	
	/**
	 * 通过key获取zset中value的score值,返回Integer
	 * @param key
	 * @param member
	 * @return
	 */
	public Integer zscoreForInt(String key,String member,RedisConnectionEnum redisEnum) {
		Double score = zscore(key, member,redisEnum);
		if (score == null) {
			return null;
		} else {
			return score.intValue();
		}
	}
	
	/**
	 * 通过key删除在zset中指定的value
	 * @param key
	 * @param member
	 * @return
	 */
	public long zrem(String key,String member,RedisConnectionEnum redisEnum){
		StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
		ZSetOperations<String, String> opsForZSet = stringRedisTemplate.opsForZSet();
		return opsForZSet.remove(key, member);
	}
	
	/**
	 * 修改一个key 的 名字
	 */
	public void rename(String oldkey,String newKey,RedisConnectionEnum redisEnum){
		StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
		stringRedisTemplate.rename(oldkey, newKey);
	}
	/**
	 * 通过key删除指定score区间内zset中的value
	 * @param key 
	 * @param max 
	 * @param min 
	 * @return
	 */
	public void zrangeDelByScore(String key, double min, double max,RedisConnectionEnum redisEnum){
		StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
		ZSetOperations<String, String> opsForZSet = stringRedisTemplate.opsForZSet();
		opsForZSet.removeRangeByScore(key, min, max);
	}
	
	/**
	 * 通过key删除指定坐标区间内的zset中的value
	 * @param key
	 * @param start
	 * @param end
	 */
	public void zremRangeByRank(String key, long start, long end,RedisConnectionEnum redisEnum) {
		StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
		ZSetOperations<String, String> opsForZSet = stringRedisTemplate.opsForZSet();
		opsForZSet.removeRange(key, start, end);
	}
	
	/**
	 * 通过key 获取size
	 * @param key 
	 * @param max 
	 * @param min 
	 * @return
	 */
	public long zsize(String key,RedisConnectionEnum redisEnum){
		StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
		ZSetOperations<String, String> opsForZSet = stringRedisTemplate.opsForZSet();
		Long size = opsForZSet.size(key);
		return size;
	}
	/**
	 * 设定一个key的生命周期 （时间单位：秒）
	 * @param key 
	 * @param max 
	 * @param min 
	 * @return
	 */
	public void expire(String key,long timeOut,RedisConnectionEnum redisEnum){
		StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
		stringRedisTemplate.expire(key, timeOut,TimeUnit.SECONDS);
	}
	/**
	 * 删掉多个key（可以使用*作为替代任意长度字符）
	 * 例delKeys("news:*");
	 * @param startWithKeys 名字的开头，手动拼接*
	 */
	public void delKeys(String startWithKeys,RedisConnectionEnum redisEnum){
		List<String> keys = this.keys(startWithKeys,redisEnum);
		if (keys!=null&&keys.size()>0) {
			this.delete(keys,redisEnum);
		}
	};
    
    /**
     * 向redis指定的db中存入key和value以及设置生存时间
     * 如果key已经存在 则覆盖
     * @param key
     * @param value
     * @param time    有效时间(默认时间单位为秒)
     * @param dbNum   选择数据库(默认为db0)
     */
    public void set(String key,String value,Long time,RedisConnectionEnum redisEnum){
    	StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
    	ValueOperations<String, String> opsForValue = stringRedisTemplate.opsForValue();
    	// 默认时间单位为秒
    	opsForValue.set(key, value, time, TimeUnit.SECONDS);
    }
    
    /**
     * 通过key获取指定的value
     * @param key
     * @param dbNum   选择数据库(默认为db0)
     * @return 没有返回null
     */
    public String get(String key,RedisConnectionEnum redisEnum) {
    	StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
        return stringRedisTemplate.opsForValue().get(key);
    }
    /**
	 * 模糊查找keys 支持用*站位 
	 * @param dbNum   选择数据库(默认为db0)
	 */
	public List<String> keys(String vageuStr,RedisConnectionEnum redisEnum){
		StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
		Set<String> keys = stringRedisTemplate.keys(vageuStr);
		Iterator<String> iterator = keys.iterator();
		List<String> list = new ArrayList<>(); 
		while (iterator.hasNext()) {
			String string = (String) iterator.next();
			list.add(string);
		}
		return list;
	}
    /**
     * 根据key删除指定元素
     * @param dbNum   选择数据库(默认为db0)
     */
    public void delete(String key,RedisConnectionEnum redisEnum) {
    	StringRedisTemplate stringRedisTemplate = choseConnection(redisEnum);
        stringRedisTemplate.delete(key);
    }
}





