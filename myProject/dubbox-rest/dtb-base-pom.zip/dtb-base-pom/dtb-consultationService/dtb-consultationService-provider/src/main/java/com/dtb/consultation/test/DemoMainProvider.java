package com.dtb.consultation.test;

import java.io.IOException;

import org.springframework.context.support.ClassPathXmlApplicationContext;



public class DemoMainProvider {
	public static void main(String[] args) throws IOException {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String []{"spring/spring-context.xml"});
    	context.start();
//    	ConsultationService consultationService = (ConsultationService)context.getBean("consultationService"); // 获取远程服务代理
//    	consultationService.show("啊啊啊");
    	System.in.read();
	}
}
