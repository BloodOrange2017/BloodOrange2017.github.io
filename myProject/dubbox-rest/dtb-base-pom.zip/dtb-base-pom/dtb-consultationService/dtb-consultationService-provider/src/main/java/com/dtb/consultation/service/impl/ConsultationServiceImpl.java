package com.dtb.consultation.service.impl;

import javax.annotation.Resource;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dtb.common.annotation.ReadOnly;
import com.dtb.consultation.api.model.User;
import com.dtb.consultation.api.service.ConsultationService;
import com.dtb.consultation.mapper.ConsultationMapper;
import com.dtb.member.redis.RedisConnectionEnum;
import com.dtb.member.redis.RedisOperate;
@Service("consultationService")
@com.alibaba.dubbo.config.annotation.Service(interfaceClass=com.dtb.consultation.api.service.ConsultationService.class, protocol = {"rest", "dubbo"}, retries=0)
public class ConsultationServiceImpl implements ConsultationService{
	@Autowired
	private ConsultationMapper consultationMapper;
	public void show(String message) {
		System.out.println("接收内容:"+message);
	}
	@ReadOnly
	public User selectUser(String mobile) {
		System.out.println("provider进来了 ");
		return consultationMapper.selectUserByMobile(mobile);
	}
	/***
	 * 测试事务
	 * @throws Exception 
	 */
	@Resource
	private RedisOperate redisOperate;
	public void TestTransaction(String mobile) throws Exception {
		System.out.println(redisOperate.keys("config:*", RedisConnectionEnum.SYSTEM_VALUE));
		System.out.println(consultationMapper.selectUserByMobile(mobile));
		consultationMapper.testUpdate(mobile);
		System.out.println(consultationMapper.selectUserByMobile(mobile));
		//throw new Exception();
	}

}
