package com.dtb.base.exception;

public class CheckParamException extends CustomException{
	public CheckParamException() {
		super("EXCEPTION: please check you params,because dont achieve want result!",null);
	}
	public CheckParamException(Object object) {
		super("EXCEPTION: please check you params,because dont achieve want result!",object);
	}
	public CheckParamException(String string, Object object) {
		super(string,object);
	}
	public CheckParamException(String string, Object object,Throwable cause) {
		super(string,object,cause);
	}
}
