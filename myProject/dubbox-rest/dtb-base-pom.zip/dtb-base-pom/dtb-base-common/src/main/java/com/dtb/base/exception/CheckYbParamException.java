package com.dtb.base.exception;

public class CheckYbParamException extends CheckParamException{
	public CheckYbParamException() {
		super("EXCEPTION: 易宝参数检查错误，请检查参数",null);
	}
	public CheckYbParamException(Object object) {
		super("EXCEPTION: 易宝参数检查错误，请检查参数",object);
	}
	public CheckYbParamException(String string, Object object) {
		super(string,object);
	}

}
