package com.dtb.base.exception;

public class UserCouponException extends UserAssertException{
	public UserCouponException() {
		super("EXCEPTION: 优惠券使用异常!",null);
	}
	public UserCouponException(Object object) {
		super("EXCEPTION: 优惠券使用异常!",object);
	}
	public UserCouponException(String string, Object object) {
		super(string,object);
	}

}
