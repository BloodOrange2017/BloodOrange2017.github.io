package com.dtb.base.exception;

public class DBQueryException extends DBCheckException{
	public DBQueryException() {
		super("EXCEPTION: please check you sql and business,because dont achieve want query result!",null);
	}
	public DBQueryException(Object object) {
		super("EXCEPTION: please check you sql and business,because dont achieve want query result!",object);
	}
	public DBQueryException(String string, Object object) {
		super(string,object);
	}

}
