package com.dtb.base.exception;

public class UserScoreException extends UserAssertException{
	public UserScoreException() {
		super("EXCEPTION:用户积分出现异常!",null);
	}
	public UserScoreException(Object object) {
		super("EXCEPTION:用户积分出现异常!",object);
	}
	public UserScoreException(String string, Object object) {
		super(string,object);
	}
}
