package com.dtb.service.impl;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dtb.entity.User;
import com.dtb.mapper.DemoUserMapper;
import com.dtb.service.DemoUserService;
@Service("demoUserService")
public class DemoUserServiceImpl implements DemoUserService{
	@Autowired
	private DemoUserMapper demoUserMapper;
	public User selectUserByMoblie(String Mobile) {
		return demoUserMapper.selectUserByMoblie(Mobile);
	}
	public int updateUser(User user) {
		return demoUserMapper.updateUser(user);
	}
	public void Transaction() throws Exception {
		User user = selectUserByMoblie("18519004800");
		user.setBalance(300d);
		int ret = updateUser(user);
		System.out.println(selectUserByMoblie("18519004800"));
		throw new SQLException();
		
	}
}
