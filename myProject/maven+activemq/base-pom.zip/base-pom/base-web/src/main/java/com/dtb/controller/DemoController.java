package com.dtb.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dtb.activemq.QueueSender1;
import com.dtb.entity.User;
import com.dtb.service.DemoUserService;
@Controller
public class DemoController {
	@Resource
	private DemoUserService demoUserService;
	@Resource
	private QueueSender1 queueSender;
	@RequestMapping("/")
	@ResponseBody
	public User getUser() throws Exception{
		//demoUserService.Transaction();
		queueSender.send("MyQueue", "test2018-08-13");
		return demoUserService.selectUserByMoblie("18519004800");
	}
}
