package com.dtb.base.exception;

public class UserAssertException extends UserNotFindException{
	public UserAssertException() {
		super("EXCEPTION: 用户资产查询无结果!",null);
	}
	public UserAssertException(Object object) {
		super("EXCEPTION: 用户资产查询无结果!",object);
	}
	public UserAssertException(String string, Object object) {
		super(string,object);
	}
	public UserAssertException(String string, Object object, Exception e) {
		super(string,object,e);
	}

}
