package com.dtb.base.exception;

public class SystemValueException extends CustomException{
	public SystemValueException() {
		super("EXCEPTION: please check you sql and business,because get system value is null!",null);
	}
	public SystemValueException(Object object) {
		super("EXCEPTION: please check you sql and business,because get system value is null!",object);
	}
	public SystemValueException(String string, Object object) {
		super(string,object);
	}


}
