package com.dtb.base.exception;

public class DBCheckException extends CheckParamException{
	public DBCheckException() {
		super("EXCEPTION: please check you sql and business,because dont achieve want result!",null);
	}
	public DBCheckException(Object object) {
		super("EXCEPTION: please check you sql and business,because dont achieve want result!",object);
	}
	public DBCheckException(String string, Object object) {
		super(string,object);
	}

}
