package com.dtb.base.exception;

public class UserDisableException extends UserNotFindException{
	public UserDisableException() {
		super("EXCEPTION: this user is disable!",null);
	}
	public UserDisableException(Object object) {
		super("EXCEPTION: this user is disable!",object);
	}
	public UserDisableException(String string, Object object) {
		super(string,object);
	}


}
