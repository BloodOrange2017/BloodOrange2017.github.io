package com.dtb.base.exception;

public class SynchronizationValueException extends SystemValueException{
	public SynchronizationValueException() {
		super("EXCEPTION:同步信息失败!",null);
	}
	public SynchronizationValueException(Object object) {
		super("EXCEPTION:同步信息失败!",object);
	}
	public SynchronizationValueException(String string, Object object) {
		super(string,object);
	}

}
