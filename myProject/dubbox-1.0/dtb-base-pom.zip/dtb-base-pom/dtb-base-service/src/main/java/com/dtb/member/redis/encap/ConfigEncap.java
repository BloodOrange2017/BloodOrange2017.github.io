package com.dtb.member.redis.encap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dtb.base.entity.SystemValue;
import com.dtb.common.service.SystemValueService;
import com.dtb.common.util.StringUtil;
import com.dtb.member.redis.RedisConnectionEnum;
import com.dtb.member.redis.RedisOperate;


/**
 * 3.系统设定值(t_system_value)
 * config_redis封装类
 * @author denghui
 *
 */
@Component
public class ConfigEncap {

	@Autowired
	RedisOperate redisOperate;//redis操作工具类
	
	@Autowired
	SystemValueService systemValueService;
	
	 /**
     * 通过key获取指定的value
     * @param key
     * @return 没有返回null
     */
    public String getValueByKey(String key) {
        String str = redisOperate.get("config:"+key,RedisConnectionEnum.SYSTEM_VALUE);
        //若redis中没有就从数据库查
        if (StringUtil.isEmpty(str)) {
			try {
				SystemValue systemValueByKey = systemValueService.getSystemValueByKey(key);
				String retStr = null;
				if (systemValueByKey != null) {
					retStr = String.valueOf(systemValueService.getSystemValueByKey(key).getValue());
					if (StringUtil.isEmpty(retStr)) {
						return null;
					}
				}
				return retStr;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		} else {
			return str;
		}
        
    }
    
    /**
     * 向redis存入key和value
	 * 如果key已经存在 则覆盖
     * @param key
     * @param value
     */
    public void setKeyValue(String key,String value) {
    	//先删除相应的key
    	redisOperate.delete("config:"+key,RedisConnectionEnum.SYSTEM_VALUE);
    	//再放到redis中
    	redisOperate.set("config:"+key, value,RedisConnectionEnum.SYSTEM_VALUE);
	}
}
