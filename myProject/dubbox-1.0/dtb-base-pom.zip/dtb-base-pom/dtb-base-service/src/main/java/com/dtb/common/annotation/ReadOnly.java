package com.dtb.common.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


@Target({ ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
public @interface ReadOnly {
	/**
	 * 负载策略（未完成）
	 * @return
	 */
	String strategy() default "default";
	/**
	 * 指定读库(未完成)
	 * @return
	 */
	String dbNum() default "1";
}
