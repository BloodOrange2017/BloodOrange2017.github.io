package com.dtb.common.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * String类型工具类
 * 
 * @author jinxin
 */
public class StringUtil {
	private static final String randChars = "0123456789abcdefghigklmnopqrstuvtxyzABCDEFGHIGKLMNOPQRSTUVWXYZ";
	private static Random random = new Random();
	/**
	 * 判断字符串是否为空
	 * 
	 * @param s
	 * @return
	 */
	public static boolean isEmpty(String s) {
		return null == s || s.trim().length() <= 0 || s.trim().equalsIgnoreCase("null");
	}

	/**
	 * 判断字符串是否为非空
	 * 
	 * @param s
	 * @return
	 */
	public static boolean isNotEmpty(String s) {
		return null != s && s.trim().length() > 0;
	}
	
	//判断是否为日期  以空格/中划线/斜杠分隔
    public static boolean isDate(String strDate){
    	Pattern pattern = Pattern
                .compile("^((\\d{2}(([02468][048])|([13579][26]))[\\-\\/\\s]?((((0?[13578])|(1[02]))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(3[01])))|(((0?[469])|(11))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(30)))|(0?2[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])))))|(\\d{2}(([02468][1235679])|([13579][01345789]))[\\-\\/\\s]?((((0?[13578])|(1[02]))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(3[01])))|(((0?[469])|(11))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(30)))|(0?2[\\-\\/\\s]?((0?[1-9])|(1[0-9])|(2[0-8]))))))(\\s(((0?[0-9])|([1-2][0-3]))\\:([0-5]?[0-9])((\\s)|(\\:([0-5]?[0-9])))))?$");
        Matcher m = pattern.matcher(strDate);
        if (m.matches()) {
            return true;
        } else {
            return false;
        }
    }
	
	/**
	 * 将json字符串转化成List<Map<String,Object>>
	 * @param str
	 * @return
	 */
	public static List<List<Map<String,Object>>> stringToListMap(String str){
		List<List<Map<String,Object>>> listListMap = new ArrayList<List<Map<String,Object>>>();
		List<Map<String,Object>> listMap = null;
        JSONArray json = JSONArray.fromObject(str); // 首先把字符串转成 JSONArray  对象
		if(json.size()>0){
		  for(int i=0;i<json.size();i++){
		    net.sf.json.JSONObject job = json.getJSONObject(i);  // 遍历 jsonarray 数组，把每一个对象转成 json 对象
		    @SuppressWarnings("rawtypes")
			Iterator it = job.keys(); 
		    listMap = new ArrayList<Map<String,Object>>();
		    
		    Map<String,Object> dataMap = null;
	        while (it.hasNext()) {  
	        	dataMap = new HashMap<String,Object>();
	        	String key = String.valueOf(it.next());
	        	String value = String.valueOf(job.get(key));
	            dataMap.put(key, value);
	            listMap.add(dataMap);
	        }
	        listListMap.add(listMap);
		  }
		}
        return listListMap;
	}
	
	//用户中心获取积分种类及数量接口
	public static List<JSONObject> stringToListJson(String str){
		List<JSONObject> listJson = new ArrayList<JSONObject>();
        JSONArray json = JSONArray.fromObject(str); // 首先把字符串转成 JSONArray  对象
		if(json.size()>0){
		  for(int i=0;i<json.size();i++){
		    listJson.add(json.getJSONObject(i));
		  }
		}
        return listJson;
	}
	
	public static List<Map<String,Object>> stringToListM(String str){
		List<Map<String,Object>> listMap = new ArrayList<Map<String,Object>>();
        JSONArray json = JSONArray.fromObject(str); // 首先把字符串转成 JSONArray  对象
		if(json.size()>0){
		  for(int i=0;i<json.size();i++){
		    net.sf.json.JSONObject job = json.getJSONObject(i);  // 遍历 jsonarray 数组，把每一个对象转成 json 对象
		    @SuppressWarnings("rawtypes")
			Iterator it = job.keys(); 
		    Map<String,Object> dataMap = new HashMap<String,Object>();
	        while (it.hasNext()) {  
	        	String key = String.valueOf(it.next());
	        	String value = String.valueOf(job.get(key));
	            dataMap.put(key, value);
	        }
	        listMap.add(dataMap);
	        dataMap.clear();
		  }
		}
        return listMap;
	}

	/**
	 * 判断字符串数组是否为空
	 * 
	 * @param sArray
	 * @return
	 */
	public static boolean isEmpty(String[] sArray) {
		if (ArrayUtil.isEmpty(sArray)) {
			return true;
		}
		for (String s : sArray) {
			if (StringUtil.isEmpty(s)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 判断两个字符串是否相等
	 * 
	 * @param s1
	 * @param s2
	 * @return
	 */
	public static boolean isEqual(String s1, String s2) {
		String s11 = null == s1 ? String.valueOf("") : s1;
		String s22 = null == s2 ? String.valueOf("") : s2;
		return s11.trim().equals(s22.trim());
	}

	/**
	 * 判断字符串数组是否包含给定字符串
	 * 
	 * @param sArray
	 * @param s
	 * @return
	 */
	public static boolean isContain(String[] sArray, String s) {
		if (ArrayUtil.isEmpty(sArray)) {
			return null == s;
		}
		for (String temp : sArray) {
			if (StringUtil.isEqual(temp, s)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 将数组合并成字符串
	 * 
	 * @param objs
	 * @param nulltoken
	 * @param splittoken
	 * @return
	 */
	public static String mergeString(Object[] objs, String nulltoken,
			String splittoken) {
		if (ArrayUtil.isEmpty(objs)) {
			return null;
		}
		StringBuilder sb = new StringBuilder("");
		String nvl = null == nulltoken ? "null" : nulltoken;
		String svalue = null;
		for (int i = 0; i < objs.length; i++) {
			if (i > 0 && null != splittoken) {
				sb.append(splittoken);
			}
			svalue = objs[i] == null ? null : objs[i].toString();
			if (StringUtil.isNotEmpty(svalue)) {
				sb.append(svalue);
			} else {
				sb.append(nvl);
			}
		}
		return sb.toString();
	}

	/**
	 * 合并字符串
	 * 
	 * @param obj1
	 * @param obj2
	 * @return
	 */
	public static String mergeString(Object obj1, Object obj2) {
		Object[] objs = new Object[] { obj1, obj2 };
		return StringUtil.mergeString(objs, null, null);
	}

	/**
	 * 取字符串非空值
	 * 
	 * @param s
	 * @return
	 */
	public static String toNotNullValue(String s) {
		return null == s ? new String("") : s.trim();
	}

	/**
	 * 字符串数组去除空元素
	 * 
	 * @param sArray
	 * @return
	 */
	public static String[] removeNull(String[] sArray) {
		if (ArrayUtil.isEmpty(sArray)) {
			return null;
		}
		List<String> retList = new ArrayList<String>();
		for (String s : sArray) {
			if (StringUtil.isEmpty(s)) {
				continue;
			}
			retList.add(s);
		}
		return retList.toArray(new String[0]);
	}

	/**
	 * 字符串数组去除给定字符串
	 * 
	 * @param sArray
	 * @param removeS
	 * @return
	 */
	public static String[] removeString(String[] sArray, String removeS) {
		if (ArrayUtil.isEmpty(sArray)) {
			return null;
		}
		List<String> retList = new ArrayList<String>();
		for (String s : sArray) {
			if (!StringUtil.isEqual(s, removeS)) {
				retList.add(s);
			}
		}
		return retList.toArray(new String[0]);
	}

	/**
	 * 字符串格式化
	 * 
	 * @param s
	 * @param objs
	 * @return
	 */
	public static String format(String s, Object... objs) {
		return String.format(s, objs);
	}
	
	/**
	 * get a substring of the original string
	 * the length of substring will not be longer than the parameter length
	 * @param str
	 * @param beginIndex
	 * @param length
	 * @return
	 */
	public static String substring(String str, int beginIndex, int length) {
		
		int actualLength=str.length();
		
		String substr="";
		if(actualLength<beginIndex+length){
			substr=str.substring(beginIndex);
		}else{
			substr=str.substring(beginIndex,beginIndex+length);
		}
		
		return substr;
	}
	
	/**
	 * 左填充
	 * @param c 填充的字符
	 * @param length 填充后的长度
	 * @param content 源串
	 * @return
	 */
	public static String flushLeft(String c, long length, String content) {
		String str = "";
		String cs = "";
		if (content.length() > length) {
			str = content;
		} else {
			for (int i = 0; i < length - content.length(); i++) {
				cs = cs + c;
			}
		}
		str = cs + content;
		return str;
	}
	
	/**
	 * 对数字整数化，只保留最高位，其余为填0
	 * @param str 源数字
	 * @param mixlen 该长度以下不处理
	 * @return 
	 */
	public static String heightestSafe(String str, int mixlen){
		int strLen = str.length();
		if (strLen <= mixlen){
			return str;
		}
		long c = 1;
		for (int i = 0; i < strLen - 1; i++){
			c = c * 10;
		}
		return String.valueOf((Long)(Long.valueOf(str) / c) * c);
	}
	
	//随机字符串
	public static String getRandStr(int length, boolean isOnlyNum) {
		int size = isOnlyNum ? 10 : 62;
		StringBuffer hash = new StringBuffer(length);
		for (int i = 0; i < length; i++) {
			hash.append(randChars.charAt(random.nextInt(size)));
		}
		return hash.toString();
	}
	
    //根据时间获取ID
	public static String getIdByDate() {
		Date now = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		String str = sdf.format(now);
		str += getRandStr(8, true);
		return str;
	}
    
	//根据实际获取短ID
	public static String getShortIdByDate() {
		Date now = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmmssSSS");
		String str = sdf.format(now);
		str += getRandStr(8, true);
		return str;
	}
	
	// 非负整数
	public static boolean isNotMinusNum(String s) {
		Pattern pattern = Pattern.compile("[0-9]*");
		Matcher isNum = pattern.matcher(s);
		return isNum.matches();
	}

	public static String getOnlineIP(HttpServletRequest request) {
		String onlineip = "";
		onlineip = request.getHeader("x-forwarded-for");
		if (StringUtil.isEmpty(onlineip) || "unknown".equalsIgnoreCase(onlineip)) {
			onlineip = request.getHeader("X-Real-IP");
		}
		if (StringUtil.isEmpty(onlineip) || "unknown".equalsIgnoreCase(onlineip)) {
			onlineip = request.getRemoteAddr();
		}
		onlineip = onlineip != null && onlineip.matches("^[\\d\\.]{7,15}$") ? onlineip
				: "unknown";
		return onlineip;
	}
	
	/**
     * 将整形数据转换成固定长度的字符串，左侧补0
     * @param num		要转化为字符串的整形数据
     * @param length	要转换的总长度
     * @return
     */
    public static String IntToString(int num,int length){
    	String number = String.valueOf(num);
    	if(number.length() > length){
    		return null;
    	}
    	for(int i=number.length();i<length;i++){
    		number = "0"+number;
    	}
    	return number;
    }
	
	public static void main(String arg[]){
		System.out.println(heightestSafe("9", 1));
		System.out.println(heightestSafe("99", 1));
		System.out.println(heightestSafe("999", 1));
		System.out.println(heightestSafe("9999", 1));
		System.out.println(IntToString(34,9));
	}
	
	//邮箱地址
	public static boolean isEmail(String s){
		Pattern pattern = Pattern.compile("^[\\w-]+(\\.[\\w-]+)*@[\\w-]+(\\.[\\w-]+)+$");
	    Matcher isNum = pattern.matcher(s);
	    return isNum.matches();
	}
	/**
     * 验证手机号码格式是否正确
     * @param mobiles
     * @return  true 表示正确  false表示不正确
     */
    public static boolean isMobileNum(String mobiles) {
        Pattern p = Pattern.compile("^((13[0-9])|(17[0-9])|(15[0-9])|(18[0-9]))\\d{8}");
        Matcher m = p.matcher(mobiles);
        return m.matches();
    }
    
    public static int checkPassword(String pwd) {
    	int ret = 0;
		if (pwd == null || pwd.trim().length() == 0) {
			ret = 1;
		} else {
			if (pwd.length() < 6) {
				ret = 3;//密码长度过低
			}
			
			Pattern p = Pattern
					.compile("^[A-Za-z0-9@#$%!~&\\^\\?\\.\\*]{6,22}$");
			Matcher m = p.matcher(pwd);
			boolean isok = m.matches();
			if (!isok) {
				ret = 2;
			}
		}
		return ret;
	}
    
    public static Map<String, Object> parseJSON2Map(String jsonStr) {
		Map<String, Object> map = new HashMap<String, Object>();
		// 最外层解析
		JSONObject json = JSONObject.fromObject(jsonStr);
		for (Object k : json.keySet()) {
			Object v = json.get(k);
			// 如果内层还是数组的话，继续解析
			if (v instanceof JSONArray) {
				List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
				Iterator<?> it = ((JSONArray) v).iterator();
				while (it.hasNext()) {
					JSONObject json2 = (JSONObject) it.next();
					list.add(parseJSON2Map(json2.toString()));
				}
				map.put(k.toString(), list);
			} else {
				map.put(k.toString(), v);
			}
		}
		return map;
	}
    
    
    public static String map2jason(Map<String, Object> requestMap) {
		JSONObject jsonObject = JSONObject.fromObject(requestMap);
		return jsonObject.toString();
	}
    
    
	public static boolean checkUseName(String pwd) {
		boolean ret = true;
		if (pwd == null || pwd.trim().length() == 0) {
			ret = false;
		} else {
			Pattern p = Pattern
					.compile("^[A-Za-z0-9_]{6,22}$");
			Matcher m = p.matcher(pwd);
			ret = m.matches();
			if (!ret) {
				ret = false;
			}
		}
		return ret;
	}
}