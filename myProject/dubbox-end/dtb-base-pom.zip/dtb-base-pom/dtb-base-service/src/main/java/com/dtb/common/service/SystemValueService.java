package com.dtb.common.service;

import java.util.List;
import java.util.Map;

import com.dtb.base.entity.SystemValue;


public interface SystemValueService {

	List<SystemValue> queryAllSystemValue();

	SystemValue getSystemValueByKey(String key);

	int updateSystemValueByKey(SystemValue systemValue);

	int insertSystemValue(SystemValue systemValue);
	
	int batchUpdateByKey(List<Map<String,Object>> list);
}
