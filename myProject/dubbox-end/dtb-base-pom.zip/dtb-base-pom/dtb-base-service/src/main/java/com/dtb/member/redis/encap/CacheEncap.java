package com.dtb.member.redis.encap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dtb.member.redis.RedisConnectionEnum;
import com.dtb.member.redis.RedisOperate;


/**
 * 4.各种统计结果（系统点总量、兑换总额、加权均价、公允点值、上周公允点值、公告时间、注销总点量、上一交易日加权均价）
 * cache_redis封装类
 * @author denghui
 *
 */
@Component
public class CacheEncap {

	@Autowired
	RedisOperate redisOperate;//redis操作工具类
	
	 /**
     * 通过key获取指定的value
     * @param key
     * @return 没有返回null
     */
    public String getValueByKey(String key) {
        String str = redisOperate.get("cache:"+key,RedisConnectionEnum.COMMON_ACTIVITY_CONFIG);
        return str;
    }
    
    /**
     * 向redis存入key和value
	 * 如果key已经存在 则覆盖
     * @param key
     * @param value
     */
    public void setKeyValue(String key,String value) {
    	//先放到redis中
    	redisOperate.set("cache:"+key, value,RedisConnectionEnum.COMMON_ACTIVITY_CONFIG);
	}
}
