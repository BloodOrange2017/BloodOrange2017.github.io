package com.dtb.common.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dtb.base.entity.SystemValue;
import com.dtb.common.mapper.SystemValueMapper;
import com.dtb.common.service.SystemValueService;


@Service("systemValueService")
public class SystemValueServiceImpl implements SystemValueService {
	@Autowired
	private SystemValueMapper systemValueMapper;

	@Override
	public List<SystemValue> queryAllSystemValue() {
		return systemValueMapper.queryAllSystemValue();
	}

	@Override
	public SystemValue getSystemValueByKey(String key) {
		return systemValueMapper.getSystemValueByKey(key);
	}

	@Override
	public int updateSystemValueByKey(SystemValue systemValue) {
		return systemValueMapper.updateSystemValueByKey(systemValue);
	}

	@Override
	public int insertSystemValue(SystemValue systemValue) {
		return systemValueMapper.insertSelective(systemValue);
	}

	@Override
	public int batchUpdateByKey(List<Map<String, Object>> list) {
		return systemValueMapper.batchUpdateByKey(list);
	}

}
