package com.dtb.consultation.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dtb.common.annotation.ReadOnly;
import com.dtb.consultation.api.model.User;
import com.dtb.consultation.api.service.ConsultationService;
import com.dtb.consultation.mapper.ConsultationMapper;
@Service("consultationService")
public class ConsultationServiceImpl implements ConsultationService{
	@Autowired
	private ConsultationMapper consultationMapper;
	
	public void show(String message) {
		System.out.println("接收内容:"+message);
	}
	@ReadOnly
	public User selectUser(String mobile) {
		System.out.println("provider进来了 ");
		return consultationMapper.selectUserByMobile(mobile);
	}
	/***
	 * 测试事务
	 * @throws Exception 
	 */
	public void TestTransaction(String mobile) throws Exception {
		System.out.println(consultationMapper.selectUserByMobile(mobile));
		consultationMapper.testUpdate(mobile);
		System.out.println(consultationMapper.selectUserByMobile(mobile));
		//throw new Exception();
	}

}
