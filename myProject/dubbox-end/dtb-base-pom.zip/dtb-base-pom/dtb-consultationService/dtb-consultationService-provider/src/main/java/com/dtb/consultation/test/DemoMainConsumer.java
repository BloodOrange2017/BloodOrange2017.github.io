package com.dtb.consultation.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dtb.consultation.api.service.ConsultationService;



public class DemoMainConsumer {
	public static void main(String[] args) throws Exception {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("dubbo/dubbo-consumer.xml");
    	ConsultationService consultationService = (ConsultationService)context.getBean("consultationService"); // 获取远程服务代理
    	consultationService.TestTransaction("18519004800");
	}
}
