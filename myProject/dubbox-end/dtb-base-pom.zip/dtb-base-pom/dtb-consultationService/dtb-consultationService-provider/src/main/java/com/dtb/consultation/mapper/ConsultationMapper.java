package com.dtb.consultation.mapper;

import com.dtb.consultation.api.model.User;

public interface ConsultationMapper {

	User selectUserByMobile(String mobile);

	void testUpdate(String mobile);

}
