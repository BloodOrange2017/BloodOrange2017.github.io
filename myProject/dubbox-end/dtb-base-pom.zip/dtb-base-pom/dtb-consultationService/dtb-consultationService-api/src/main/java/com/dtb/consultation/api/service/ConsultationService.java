package com.dtb.consultation.api.service;

import com.dtb.consultation.api.model.User;

public interface ConsultationService {
	void show(String message);
	
	User selectUser(String mobile);
	
	void TestTransaction(String mobile) throws Exception;
}
