package com.dtb.base.exception;

public class AllowancePramsException extends UserAssertException{
	public AllowancePramsException() {
		super("EXCEPTION:补贴用户参数异常!",null);
	}
	public AllowancePramsException(Object object) {
		super("EXCEPTION:补贴用户参数异常!",object);
	}
	public AllowancePramsException(String string, Object object) {
		super(string,object);
	}

}
