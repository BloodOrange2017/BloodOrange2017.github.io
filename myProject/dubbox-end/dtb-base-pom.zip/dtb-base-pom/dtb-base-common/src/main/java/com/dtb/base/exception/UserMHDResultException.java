package com.dtb.base.exception;

public class UserMHDResultException extends UserAssertException{
	public UserMHDResultException() {
		super("EXCEPTION: 用户资产查询无结果!",null);
	}
	public UserMHDResultException(Object object) {
		super("EXCEPTION: 用户资产查询无结果!",object);
	}
	public UserMHDResultException(String string, Object object) {
		super(string,object);
	}
}
