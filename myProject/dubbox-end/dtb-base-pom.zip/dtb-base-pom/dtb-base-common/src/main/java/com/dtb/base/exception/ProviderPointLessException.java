package com.dtb.base.exception;

public class ProviderPointLessException extends UserAssertException{
	public ProviderPointLessException() {
		super("EXCEPTION: 服务商点量不足!",null);
	}
	public ProviderPointLessException(Object object) {
		super("EXCEPTION: 服务商点量不足!",object);
	}
	public ProviderPointLessException(String string, Object object) {
		super(string,object);
	}
}
