package com.dtb.base.exception;

public class FoundationLessException extends UserAssertException{
	public FoundationLessException() {
		super("EXCEPTION: 基金会点量不足!",null);
	}
	public FoundationLessException(Object object) {
		super("EXCEPTION: 基金会点量不足!",object);
	}
	public FoundationLessException(String string, Object object) {
		super(string,object);
	}
}
