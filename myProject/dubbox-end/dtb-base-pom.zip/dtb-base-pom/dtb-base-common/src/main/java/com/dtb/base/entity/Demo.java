package com.dtb.base.entity;

public class Demo {

}
