package com.dtb.base.exception;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.concurrent.LinkedBlockingQueue;

/**
 *  @author xuecheng
 * @version 2017/03/21
 */
public class CustomException extends Exception{
	/**
	 * 构造一个基本异常.
	 *
	 * @param message
	 *            信息描述
	 */
	public CustomException(String message) {
		super(message);
		super.printStackTrace(System.err);
		/**获取到报错中即将打印出去到错误信息**/
		StringWriter sw = new StringWriter();   
		super.printStackTrace(new PrintWriter(sw, true));   
		String content = sw.toString();   
		InetAddress addr = null;
        String ip = null;
        String address = null;
		try {
			addr = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			addr = null;
		}
		if (addr != null) {
			ip = addr.getHostAddress().toString();// 获得本机IP
			address = addr.getHostName().toString();// 获得本机名称
		}
		message = "【IP:"+ip+",Address:"+address+"】"+message;
		persistence(message,content,null);
	}
	/**
	 * 构造一个基本异常.
	 *
	 * @param message
	 *            信息描述
	 */
	public CustomException(String message,Object object,Throwable cause) {
		super(message,cause);
		super.printStackTrace(System.err);
		/**获取到报错中即将打印出去到错误信息**/
		StringWriter sw = new StringWriter();   
		super.printStackTrace(new PrintWriter(sw, true));   
        String content = sw.toString();   
        InetAddress addr = null;
        String ip = null;
        String address = null;
		try {
			addr = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			addr = null;
		}
		if (addr != null) {
			ip = addr.getHostAddress().toString();// 获得本机IP
			address = addr.getHostName().toString();// 获得本机名称
		}
		message = "【IP:"+ip+",Address:"+address+"】"+message;
        persistence(message,content,object);
	}
	/**
	 * 构造一个基本异常.
	 *
	 * @param message
	 *            信息描述
	 */
	public CustomException(String message,Object object) {
		super(message);
		super.printStackTrace(System.err);
		/**获取到报错中即将打印出去到错误信息**/
		StringWriter sw = new StringWriter();   
		super.printStackTrace(new PrintWriter(sw, true));   
        String content = sw.toString();   
        InetAddress addr = null;
        String ip = null;
        String address = null;
		try {
			addr = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			addr = null;
		}
		if (addr != null) {
			ip = addr.getHostAddress().toString();// 获得本机IP
			address = addr.getHostName().toString();// 获得本机名称
		}
		message = "【IP:"+ip+",Address:"+address+"】"+message;
        persistence(message,content,object);
	}
	/**
	 * 错误需要进行持久化的业务
	 */
	LinkedBlockingQueue<ExceptionLoger> fpi;
	protected  void persistence(String message,String content,Object object){
		fpi = ExceptionDataQueue.getInstance();
		fpi.offer(new ExceptionLoger(message, content, new Date(), object, true, false, true));
	};
}
