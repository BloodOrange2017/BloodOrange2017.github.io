package com.dtb.base.exception;

public class GameGoldPointException extends UserAssertException{
	public GameGoldPointException() {
		super("EXCEPTION: 点石成金业务发生异常",null);
	}
	public GameGoldPointException(Object object) {
		super("EXCEPTION: 点石成金业务发生异常",object);
	}
	public GameGoldPointException(String string, Object object) {
		super(string,object);
	}
}
