package com.dtb.base.exception;

public class BorrowOutApplyResultException extends UserAssertException{
	public BorrowOutApplyResultException() {
		super("EXCEPTION: 借点业务处理订单时，发生结果错误。",null);
	}
	public BorrowOutApplyResultException(Object object) {
		super("EXCEPTION: 借点业务处理订单时，发生结果错误。",object);
	}
	public BorrowOutApplyResultException(String string, Object object) {
		super(string,object);
	}
}
