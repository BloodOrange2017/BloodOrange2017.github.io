package com.dtb.base.exception;

public class UserYbResultException extends UserAssertException{
	public UserYbResultException() {
		super("EXCEPTION: 易宝回调成功后未能正确更新数据！",null);
	}
	public UserYbResultException(Object object) {
		super("EXCEPTION: 易宝回调成功后未能正确更新数据！",object);
	}
	public UserYbResultException(String string, Object object) {
		super(string,object);
	}
}
