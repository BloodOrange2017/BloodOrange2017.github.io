package com.dtb.base.exception;

public class UserOrderException extends UserAssertException{
	public UserOrderException() {
		super("EXCEPTION: 该用户订单出现异常！",null);
	}
	public UserOrderException(Object object) {
		super("EXCEPTION: 该用户订单出现异常！",object);
	}
	public UserOrderException(String string, Object object) {
		super(string,object);
	}

}
