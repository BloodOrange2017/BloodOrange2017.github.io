package com.dtb.base.exception;

import java.util.concurrent.LinkedBlockingQueue;


public class ExceptionDataQueue {
	private static LinkedBlockingQueue<ExceptionLoger> exceptionQueue=null;
	
	public static LinkedBlockingQueue<ExceptionLoger> getInstance(){
		if (exceptionQueue==null) {
			synchronized("111"){
				if (exceptionQueue==null) {
					exceptionQueue = new LinkedBlockingQueue<ExceptionLoger>();
				}
			}
		}
		return exceptionQueue;
	}
}
