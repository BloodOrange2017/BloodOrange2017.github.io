简介:本系统用于解决分布式事务问题
	1.采用activemq作为消息中间件
	2.消息系统具有自己的db 采用mysql
	3.使用时 在serviceImpl方法上使用注解@Producer。  消费端使用@Consumer。并保证同一broker
	4.在Producer中需要调用disTransactionService.execute(String …)来确认消息，或传递参数
	5.例子与配置均在base-distributed-transaction ，base-service ，base-web