package com.dtb.controller;

import java.util.Date;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dtb.distributed.exception.DisTransactionFileOutBoundsException;
import com.dtb.distributed.exception.DisTransactionNotResultException;
import com.dtb.distributed.exception.MustSignProducerException;
import com.dtb.entity.User;
import com.dtb.service.DemoUserService;
@Controller
public class DemoController {
	@Resource
	private DemoUserService demoUserService;
	@RequestMapping("/demo/one")
	@ResponseBody
	public User txMobile(@RequestParam(value="mobile",required=false)String mobile) throws DisTransactionNotResultException, DisTransactionFileOutBoundsException, MustSignProducerException{
		long time = new Date().getTime();
		System.out.println(mobile);
		User user = demoUserService.txProducerSelectUser("18519004800");
		System.out.println(new Date().getTime()-time);
		return user;
	}
	@RequestMapping("/demo/two")
	@ResponseBody
	public User txMobile2(@RequestParam(value="mobile",required=false)String mobile) throws DisTransactionNotResultException, DisTransactionFileOutBoundsException, MustSignProducerException{
		long time = new Date().getTime();
		System.out.println(mobile);
		User user = demoUserService.txProducerSelectUser2("18519004800");
		System.out.println(new Date().getTime()-time);
		return user;
	}
}
