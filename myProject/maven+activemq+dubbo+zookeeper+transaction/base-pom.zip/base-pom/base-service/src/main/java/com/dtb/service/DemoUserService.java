package com.dtb.service;

import com.dtb.distributed.exception.DisTransactionFileOutBoundsException;
import com.dtb.distributed.exception.DisTransactionNotResultException;
import com.dtb.distributed.exception.MustSignProducerException;
import com.dtb.entity.User;

public interface DemoUserService {
	
	public User txConsumerSelectUser(String mobile,String uuid);
	
	public User txProducerSelectUser(String mobile) throws DisTransactionNotResultException, DisTransactionFileOutBoundsException, MustSignProducerException;
	
	public User txProducerSelectUser2(String mobile) throws DisTransactionNotResultException, DisTransactionFileOutBoundsException, MustSignProducerException;
	
	public User txConsumerSelectUser2(String mobile,String uuid);
	
}
