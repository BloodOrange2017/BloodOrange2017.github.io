package com.dtb.service.impl;

import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dtb.distributed.entity.TransactionFiles;
import com.dtb.distributed.exception.DisTransactionFileOutBoundsException;
import com.dtb.distributed.exception.DisTransactionNotResultException;
import com.dtb.distributed.exception.MustSignProducerException;
import com.dtb.distributed.service.DisTransactionService;
import com.dtb.distributed.transaction.annotation.Consumer;
import com.dtb.distributed.transaction.annotation.Producer;
import com.dtb.entity.User;
import com.dtb.mapper.DemoUserMapper;
import com.dtb.service.DemoUserService;
@Service("demoUserService")
public class DemoUserServiceImpl implements DemoUserService{
	@Autowired
	private DemoUserMapper demoUserMapper;
	@Autowired
	private DisTransactionService disTransactionService;
	@Producer(broker = "DemoQueue1")
	public User txProducerSelectUser(String mobile) throws DisTransactionNotResultException, DisTransactionFileOutBoundsException, MustSignProducerException{
		disTransactionService.execute(mobile,UUID.randomUUID().toString());
		User user = demoUserMapper.selectUserByMoblie(mobile);
		System.out.println("生产者1:" +user);
		return user;
	}
	
	
	
	
	@Consumer(broker = "DemoQueue1")
	public User txConsumerSelectUser(String mobile,String uuid){
		User user = demoUserMapper.selectUserByMoblie(mobile);
		System.out.println("消费者1:接收参数" +mobile+","+uuid);
		System.out.println(new Date().getTime());
		return user;
	}



	@Producer(broker = "DemoQueue2")
	public User txProducerSelectUser2(String mobile)
			throws DisTransactionNotResultException, DisTransactionFileOutBoundsException, MustSignProducerException {
		disTransactionService.execute(mobile,UUID.randomUUID().toString());
		User user = demoUserMapper.selectUserByMoblie(mobile);
		System.out.println("生产者2:" +user);
		return user;
	}



	@Consumer(broker = "DemoQueue2")
	public User txConsumerSelectUser2(String mobile, String uuid) {
		User user = demoUserMapper.selectUserByMoblie(mobile);
		System.out.println("消费者2:接收参数" +mobile+","+uuid);
		System.out.println(new Date().getTime());
		return user;
	}

}
