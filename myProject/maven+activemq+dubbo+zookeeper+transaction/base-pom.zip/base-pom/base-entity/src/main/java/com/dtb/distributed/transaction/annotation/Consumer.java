package com.dtb.distributed.transaction.annotation;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * 用于标注分布式事务注解
 * 标注于serviceImpl方法之上,将会在消息中间键中取出并处理一个队列中数据进行处理,此处试图模拟创建一个队列消费者
 * @author xuecheng
 *
 */
@Target(METHOD)
@Retention(RUNTIME)
public @interface Consumer {
	/**
	 * 服务端名称
	 * @return
	 */
	String broker();
	/**
	 * 是否需要事务
	 * @return
	 */
	boolean sessionTransacted() default true;
	/**
	 * 一个消费者具有多少个实例
	 * @return
	 */
	int concurrentConsumers() default 1;
	/**
	 * 数据采用结构（待开发）
	 * @return
	 */
	String type() default "json";
}
