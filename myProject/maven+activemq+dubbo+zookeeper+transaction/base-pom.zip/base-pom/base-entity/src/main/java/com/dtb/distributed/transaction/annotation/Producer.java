package com.dtb.distributed.transaction.annotation;


import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;
/**
 * 用于标注分布式事务注解
 * 标注于serviceImpl方法之上,将会在消息中间键中开启一个处理事务
 * @author xuecheng
 *
 */
@Target(METHOD)
@Retention(RUNTIME)
public @interface Producer {
	String broker();
	Class<?> type() default java.lang.Object.class;
	String uuid() default "";
	String mqType() default "activemq";
}
