package com.dtb.distributed.entity;

public class TransactionFiles {
	private String file1;
	private String file2;
	private String file3;
	private String broker;
	
	public String getQueueName() {
		return broker;
	}
	public void setQueueName(String queueName) {
		this.broker = queueName;
	}
	public String getFile1() {
		return file1;
	}
	public void setFile1(String file1) {
		this.file1 = file1;
	}
	public String getFile2() {
		return file2;
	}
	public void setFile2(String file2) {
		this.file2 = file2;
	}
	public String getFile3() {
		return file3;
	}
	public void setFile3(String file3) {
		this.file3 = file3;
	}
	@Override
	public String toString() {
		return "TransactionFiles [file1=" + file1 + ", file2=" + file2 + ", file3=" + file3 + "]";
	}
	
}
