package com.dtb.distributed.exception;
/**
 * 如果service 调用了 service 并外层service没有标记注解 则抛出该异常
 * 
 * @author xuecheng
 *
 */
public class MustSignProducerException extends Exception{
	private static final long serialVersionUID = 1L;
}
