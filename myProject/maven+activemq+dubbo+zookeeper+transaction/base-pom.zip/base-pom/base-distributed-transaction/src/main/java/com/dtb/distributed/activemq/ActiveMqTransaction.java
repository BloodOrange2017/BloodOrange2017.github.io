package com.dtb.distributed.activemq;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.apache.activemq.command.ActiveMQTextMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

/**
 * ActiveMQ的消息队列模式 
 * Description:
 * 队列消息的生产者，发哦是哪个消息到队列
 * 
 * @author xuecheng
 * @date 2016年4月25日 上午10:20:20
 **/
@Component("activeMqTransaction")
public class ActiveMqTransaction {

	@Autowired
	@Qualifier("jmsQueueTemplate")
	private JmsTemplate jmsTemplate;

	/**
	 * 发送消息到指定的队列(目标)
	 * 
	 * @param queueName
	 *            队列名称
	 * @param message
	 *            消息内容
	 */
	public void send(String queueName, final String message) {
		jmsTemplate.send(queueName, new MessageCreator() {
			public Message createMessage(Session session) throws JMSException {
				ActiveMQTextMessage createTextMessage = null;
				try {
					createTextMessage = (ActiveMQTextMessage) session.createTextMessage(message);
					createTextMessage.setResponseRequired(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return createTextMessage;
			}
		});
	}
}
