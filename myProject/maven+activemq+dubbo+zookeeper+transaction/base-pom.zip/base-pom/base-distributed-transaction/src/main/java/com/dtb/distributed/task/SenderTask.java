package com.dtb.distributed.task;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.dtb.distributed.activemq.ActiveMqTransaction;
import com.dtb.distributed.entity.DisTransaction;
import com.dtb.distributed.service.DisTransactionService;
import com.dtb.mapper.DisTransactionMapper;
import com.dtb.util.JsonUtils;
@Component
public class SenderTask {
	@Autowired
	private DisTransactionService disTransactionService;
	@Autowired
	private DisTransactionMapper disTransactionMapper;
	@Autowired
	private ActiveMqTransaction activeMqTransaction;
	/**
	 * 处理事务信息中待发送的信息，变更为发送中状态
	 * @throws Exception 
	 **/ 
	@Scheduled(cron = "*/1 * * * * ?")
	public void printActionLog() throws Exception {
		List<DisTransaction> disTransactions = disTransactionService.selectNeedSend();
		for (DisTransaction transaction : disTransactions) {
			int ret = disTransactionMapper.updateStatusById(transaction.getId(), 3);
			if (ret != 1) {
				throw new Exception();
			}
			activeMqTransaction.send(transaction.getQueueName(), JsonUtils.objectToJson(transaction));
		}
	}
}
