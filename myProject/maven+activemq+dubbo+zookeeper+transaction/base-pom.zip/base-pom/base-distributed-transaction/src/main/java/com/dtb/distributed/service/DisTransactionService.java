package com.dtb.distributed.service;

import java.util.List;

import com.dtb.distributed.entity.DisTransaction;
import com.dtb.distributed.exception.DisTransactionFileOutBoundsException;
import com.dtb.distributed.exception.DisTransactionNotResultException;
import com.dtb.distributed.exception.MustSignProducerException;
import com.dtb.distributed.transaction.annotation.Producer;

public interface DisTransactionService {
	/**
	 * 初始化事务信息
	 * 
	 * @param methodPath
	 * @param uuid
	 * @return
	 * @throws DisTransactionNotResultException
	 * @throws MustSignProducerException 
	 */
	DisTransaction initTransaction(String uuid, String methodPath, Producer inpouringTransaction)
			throws DisTransactionNotResultException;

	/**
	 * 确认事务
	 * 
	 * @throws DisTransactionNotResultException
	 * @throws MustSignProducerException 
	 * @throws DisTransactionFileOutBoundsException
	 */
	void execute(String... args) throws MustSignProducerException;

	/**
	 * 事务进入带发送状态
	 * 
	 * @param initTransaction
	 * @throws DisTransactionNotResultException
	 */
	void toSendTransaction(DisTransaction initTransaction) throws DisTransactionNotResultException;

	/**
	 * 清除不能发放数据
	 * 
	 * @param initTransaction
	 * @throws DisTransactionNotResultException
	 */
	void deleteTransaction(DisTransaction initTransaction) throws DisTransactionNotResultException;

	/**
	 * 查询所有待发送
	 * 
	 * @return
	 */
	List<DisTransaction> selectNeedSend();

	/**
	 * 状态更新
	 * 
	 * @param id
	 * @param status
	 * @throws Exception
	 */
	void updateStatusById(Integer id, int status) throws Exception;
}
