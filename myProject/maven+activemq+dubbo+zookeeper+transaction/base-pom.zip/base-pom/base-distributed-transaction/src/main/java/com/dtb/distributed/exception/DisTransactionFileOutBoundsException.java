package com.dtb.distributed.exception;

public class DisTransactionFileOutBoundsException extends Exception{
	private static final long serialVersionUID = 1L;

}
