package com.dtb.distributed.exception;
/**
 * 消息系统没有得到想要得到的数据时 抛出这个异常
 * @author xuecheng
 *
 */
public class DisTransactionNotResultException extends Exception{
	private static final long serialVersionUID = 1L;

}
