package com.dtb.distributed.transaction.core;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Session;

import org.apache.activemq.command.ActiveMQDestination;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.jms.listener.SessionAwareMessageListener;

import com.dtb.distributed.entity.DisTransaction;
import com.dtb.distributed.service.DisTransactionService;
import com.dtb.distributed.transaction.annotation.Consumer;
import com.dtb.util.JsonUtils;

/**
 * 公共的信息消费者 这个消费者在初始化的时候会变成多个实例，每个实例都对应自己的broker
 * 
 * @author xuecheng
 *
 */
public class BaseReceiver implements SessionAwareMessageListener<ActiveMQTextMessage> {
	private HashMap<String, Object> ConsumerMaps;
	@Autowired
	private ApplicationContext applicationContext;
	@Autowired
	private DisTransactionService disTransactionService;

	@SuppressWarnings("unchecked")
	public void onMessage(ActiveMQTextMessage message, Session session) throws JMSException {
		String broker = null;
		Object instance = null;
		Method method = null;
		Consumer consumer = null;
		try {
			/** broker名字,初始这个消费者时是没有broker的,通过筛选Destination得来,为了提高效率，仅获取一次即可 **/
			if (broker == null || "".equals(broker)) {
				ActiveMQDestination destination = message.getDestination();
				broker = destination.getQualifiedName().split("//")[1];
			}
			/**
			 * 通过初始化得来的实例 这里将会把这个实例 去跟spring beans 对比 将同类型，通方法的bean 取出来赋给object
			 * 
			 **/
			Map<String, Object> consumerMsg = (Map<String, Object>) ConsumerMaps.get(broker);
			instance = consumerMsg.get("instance");
			if (instance == null) {
				Class<?> clazz = (Class<?>) consumerMsg.get("class");
				instance = applicationContext.getBean(clazz);
				consumerMsg.put("instance", instance);
			}
			/** 将method 与注解信息均存入该类 **/
			method = (Method) consumerMsg.get("method");
			consumer = (Consumer) consumerMsg.get("annotation");
			String text = message.getText();
			DisTransaction disTransaction = null;
			Object[] args = null;
			disTransaction = JsonUtils.jsonToPojo(text, DisTransaction.class);
			if (disTransaction.getFile3() != null) {
				args = new Object[3];
				args[0] = disTransaction.getFile1();
				args[1] = disTransaction.getFile2();
				args[2] = disTransaction.getFile3();
			} else if (disTransaction.getFile2() != null) {
				args = new Object[2];
				args[0] = disTransaction.getFile1();
				args[1] = disTransaction.getFile2();
			} else if (disTransaction.getFile1() != null) {
				args = new Object[1];
				args[0] = disTransaction.getFile1();
			}
			/** 实际调用 **/
			if (args != null) {
				method.invoke(instance, args);
			} else {
				method.invoke(instance);
			}
			/** 成功处理后，状态标记为已消费 **/
			disTransactionService.updateStatusById(disTransaction.getId(), 4);
			if (consumer.sessionTransacted()) {
				session.commit();
			}
		} catch (Exception e) {
			e.printStackTrace();
			if (consumer.sessionTransacted()) {
				session.rollback();
			}
		}
	}

	public HashMap<String, Object> getConsumerMaps() {
		return ConsumerMaps;
	}

	public void setConsumerMaps(HashMap<String, Object> consumerMaps) {
		ConsumerMaps = consumerMaps;
	}

}
