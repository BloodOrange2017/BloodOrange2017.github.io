package com.dtb.distributed.transaction.core;


import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.jms.connection.JmsTransactionManager;
import org.springframework.jms.listener.DefaultMessageListenerContainer;

import com.dtb.distributed.transaction.annotation.Consumer;
import com.dtb.distributed.transaction.annotation.Producer;
import com.dtb.distributed.transaction.util.ClassUtil;
/**
 * 初始化注解加载器-请配置ioc
 * @author xuecheng
 *
 */
public class AnnotationConfiguration{
	private HashMap<String,Producer> ProducerMaps = null;
	private HashMap<String,Object> ConsumerMaps = null;
	private ActiveMQConnectionFactory connectionFactory;
	private BaseReceiver baseReceiver;
	private JmsTransactionManager transactionManager;

	public AnnotationConfiguration(String classPath,ActiveMQConnectionFactory connectionFactory,BaseReceiver baseReceiver,JmsTransactionManager transactionManager) throws InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException {
		this.connectionFactory = connectionFactory;
		this.baseReceiver = baseReceiver;
		this.transactionManager = transactionManager;
		initConfiguration(classPath);
	}
	
	public HashMap<String, Producer> getProducerMaps() {
		return ProducerMaps;
	}

	public void setProducerMaps(HashMap<String, Producer> producerMaps) {
		ProducerMaps = producerMaps;
	}
	

	public HashMap<String, Object> getConsumerMaps() {
		return ConsumerMaps;
	}

	public void setConsumerMaps(HashMap<String, Object> consumerMaps) {
		ConsumerMaps = consumerMaps;
	}
	/**
	 * 	初始化注解类
	 * @param classPath
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws SecurityException
	 */
	private void initConfiguration(String classPath) throws InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException{
		/** 获取目标包下面所有的类信息 **/
		List<Class<?>> clazzs = ClassUtil.getClasses(classPath);
		for (Class<?> clazz : clazzs) {
			Method[] methods = clazz.getMethods();
			for (Method method : methods) {
				/**满足携带生产者注解的,初始化生产者**/
				if (method.isAnnotationPresent(Producer.class)) {
					initProducerMaps(clazz,method);
				/**满足携带消费者注解的,初始化消费者**/
				}else if (method.isAnnotationPresent(Consumer.class)) {
					initConsumerMaps(clazz,method);
				}
			}
		}
	}
	/**
	 * 初始化生产者注解类信息
	 * @param clazz
	 * @param method
	 */
	private void initProducerMaps(Class<?> clazz,Method method){
		if (ProducerMaps==null) {
			ProducerMaps = new HashMap<String, Producer>();
		}
		/**取出该注解  存入生产者Map中**/
		Producer annotation = method.getAnnotation(Producer.class);
		/**存入 key:serviceImpl 类信息.方法名    value:注解内容**/
		ProducerMaps.put(clazz.getName()+"."+method.getName(), annotation);
	}
	/**
	 * 初始化消费者注解类信息
	 * @throws SecurityException 
	 * @throws NoSuchMethodException 
	 */
	private void initConsumerMaps(Class<?> clazz,Method method) throws NoSuchMethodException, SecurityException{
		if (ConsumerMaps==null) {
			ConsumerMaps = new HashMap<String, Object>();
		}
		/**获取消费者 注解**/
		Consumer annotation = method.getAnnotation(Consumer.class);
		/** 每一个消费者的具体信息  都是一个 **/
		Map<String, Object> consumerMsg = new HashMap<String, Object>();
		/**
		 * 由于消费者是接口的实现，而我们调用的是实现的接口类，所以我们需要知道这个消费者的接口是什么
		 * 注：这里的消费者实现 请将业务实现业务接口类，放在第一位，保证处理时正确获取 接口
		 * 1.获消费者取第0个实现接口
		 * 2.获取这个接口跟实现的同一个方法
		 * 3.将这些信息存入map 以备需要调用的时候执行反射执行该方法
		 * 4.执行这个方法的时候不用clazz 对象，而是从spring beans中找到同名bean 保证事务，注入，依赖等关系正确	
		 * */
		Class<?> interfaceClass = clazz.getInterfaces()[0];
		consumerMsg.put("class", interfaceClass);
		consumerMsg.put("method", interfaceClass.getMethod(method.getName(), method.getParameterTypes()));
		consumerMsg.put("annotation", annotation);
		/**
		 * 如果成功初始化消费者 必须在消息中间健中建立一个新的broker
		 * 这里采用手动建立，不依赖注入，可以保证每一个@Consumer都会至少有一个自己的broker
		 */
		DefaultMessageListenerContainer dmlc = new DefaultMessageListenerContainer();
		dmlc.initialize();
		ActiveMQQueue activeMQQueue = new ActiveMQQueue(annotation.broker());
		/**这里的链接参数均来自 spring注入,所以情事先准备好**/
		dmlc.setConnectionFactory(connectionFactory);
		dmlc.setMessageListener(baseReceiver);
		baseReceiver.setConsumerMaps(ConsumerMaps);
		dmlc.setSessionTransacted(annotation.sessionTransacted());
		if (annotation.sessionTransacted()) {
			dmlc.setTransactionManager(transactionManager);
		}
		dmlc.setConcurrentConsumers(annotation.concurrentConsumers());
		dmlc.setDestination(activeMQQueue);
		dmlc.start();
		ConsumerMaps.put(annotation.broker(), consumerMsg);
	}
}
