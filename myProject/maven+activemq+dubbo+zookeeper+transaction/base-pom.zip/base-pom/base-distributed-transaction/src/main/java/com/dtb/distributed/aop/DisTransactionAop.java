package com.dtb.distributed.aop;

import java.util.HashMap;
import java.util.UUID;

import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.beans.factory.annotation.Autowired;

import com.dtb.distributed.entity.DisTransaction;
import com.dtb.distributed.exception.DisTransactionNotResultException;
import com.dtb.distributed.exception.MustSignProducerException;
import com.dtb.distributed.service.DisTransactionService;
import com.dtb.distributed.transaction.annotation.Producer;
import com.dtb.distributed.transaction.core.AnnotationConfiguration;

/**
 * 分布式事务处理AOP
 * 1.进入业务前，现在消息管理系统中插入预发送信息
 * 2.业务中手动将参数传入，并标记这条预发送信息变更为就绪状态
 * 3.正常执行业务后将这条信息变更为 待发送状态，等待定时器处理
 * 
 * @author xuecheng
 *
 */
public class DisTransactionAop {
	@Autowired
	private AnnotationConfiguration annotationConfiguration;
	@Autowired
	private DisTransactionService disTransactionService;

	public Object surroundTransaction(ProceedingJoinPoint point) throws MustSignProducerException, DisTransactionNotResultException{
		Object proceed = null;
		DisTransaction initTransaction = this.executeProducer(point);
		try {
			proceed = point.proceed();
			if (initTransaction != null) {
				/** 生产者 正常事务处理 **/
				disTransactionService.toSendTransaction(initTransaction);
			}
		} catch (Throwable e) {
			e.printStackTrace();
			if (initTransaction != null) {
				/** 生产者 异常事务处理 **/
				disTransactionService.deleteTransaction(initTransaction);
			}
		}
		return proceed;
	}

	/**
	 * 处理生产者私有方法
	 * 
	 * @param point
	 * @return
	 * @throws MustSignProducerException 
	 * @throws DisTransactionNotResultException
	 */
	private DisTransaction executeProducer(ProceedingJoinPoint point) throws DisTransactionNotResultException{
		DisTransaction initTransaction = null;
		String methodAddress = point.toString();
		String method = methodAddress.substring(methodAddress.lastIndexOf("."), methodAddress.lastIndexOf("("));
		String methodPath = point.getTarget().toString().substring(0, point.getTarget().toString().lastIndexOf("@"))+ method;
		HashMap<String, Producer> annotationMaps = annotationConfiguration.getProducerMaps();
		if (annotationMaps != null) {
			Producer resource = annotationMaps.get(methodPath);
			if (resource != null) {/** 初始化开启分布式事务 **/
				initTransaction = disTransactionService.initTransaction(UUID.randomUUID().toString(), methodPath,resource);
			}
		}
		return initTransaction;
	}
}
