package com.dtb.distributed.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dtb.distributed.entity.DisTransaction;
import com.dtb.distributed.entity.TransactionFiles;
import com.dtb.distributed.exception.DisTransactionNotResultException;
import com.dtb.distributed.exception.MustSignProducerException;
import com.dtb.distributed.service.DisTransactionService;
import com.dtb.distributed.transaction.annotation.Producer;
import com.dtb.distributed.transaction.core.AnnotationConfiguration;
import com.dtb.mapper.DisTransactionMapper;

/**
 * 事务处理具体实现
 * @author xuecheng
 *
 */
@Service("disTransactionService")
public class DisTransactionServiceImpl implements DisTransactionService {
	@Autowired
	private DisTransactionMapper disTransactionMapper;
	@Autowired
	private AnnotationConfiguration annotationConfiguration;

	public DisTransaction initTransaction(String uuid, String methodPath, Producer resource)
			throws DisTransactionNotResultException {
		/**将一部分初始化信息传入**/
		DisTransaction transaction = new DisTransaction();
		transaction.setInsertTime(new Date());
		transaction.setMethodPath(methodPath);
		transaction.setUuid(uuid);
		transaction.setTransactionStatus(0);
		transaction.setIsDel(0);
		transaction.setQueueName(resource.broker());
		int ret = disTransactionMapper.insertSelective(transaction);
		if (ret != 1) {
			throw new DisTransactionNotResultException();
		}
		return transaction;
	}

	public void execute(String... fileStrs) throws MustSignProducerException {
		/**将使用者传入的参数封装为一个TransactionFiles**/
		TransactionFiles files = new TransactionFiles();
		if (fileStrs.length == 3) {
			files.setFile3(fileStrs[2]);
			files.setFile2(fileStrs[1]);
			files.setFile1(fileStrs[0]);
		} else if (fileStrs.length == 2) {
			files.setFile2(fileStrs[1]);
			files.setFile1(fileStrs[0]);
		} else if (fileStrs.length == 1) {
			files.setFile1(fileStrs[0]);
		}
		/**将直接获取调用该方法之上的service的栈信息，从而分析出类信息和方法信息**/
		StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
		StackTraceElement element = stackTrace[2];
		String stackName = element.toString().substring(0, element.toString().indexOf("("));
		/**从注解配置中 获取到这个类对应的注解信息**/
		Producer inpouringTransaction = annotationConfiguration.getProducerMaps().get(stackName);
		files.setQueueName(inpouringTransaction.broker());
		/**将获取到的参数与队列 名等信息 存入 消息系统，并将其修改为就绪状态**/
		int ret = disTransactionMapper.confirmTransaction(files);
		if (ret != 1) {
			throw new MustSignProducerException();
		}
	}

	public void toSendTransaction(DisTransaction initTransaction) throws DisTransactionNotResultException {
		/**将就绪状态信息变更为带发送状态
		 * 因为aop层与业务层并没有真正的数据传递
		 * 可能导致业务层标记就绪状态的信息并非是同一事务下aop建立的信息
		 * 但业务层标记的永远是第一条 信息，变更为就绪状态
		 * 所以如果即使id发生变更，aop只要保证就绪状态至少有一条信息就可以将它标记为待发送
		 * 1.尝试用id将指定信息行变更为就绪
		 * 2.如果失败将同一个QueueName的信息的就绪信息第一条标记为就绪
		 * 3.若2失败，删除这个id所建立的信息，并抛出异常(注:消息事务不受spring事务控制)
		 * **/
		int ret = disTransactionMapper.toSendTransaction(initTransaction.getId());
		if (ret != 1) {
			ret = disTransactionMapper.toSendTransactionByQueueName(initTransaction.getQueueName());
			deleteTransaction(initTransaction);
			if (ret != 1) {
				throw new DisTransactionNotResultException();
			}
		}
	}

	public void deleteTransaction(DisTransaction initTransaction) throws DisTransactionNotResultException {
		int ret = disTransactionMapper.deleteByPrimaryKey(initTransaction.getId());
		if (ret != 1) {
			throw new DisTransactionNotResultException();
		}

	}

	public List<DisTransaction> selectNeedSend() {
		return disTransactionMapper.selectNeedSend();
	}

	public void updateStatusById(Integer id, int status) throws Exception {
		int ret = disTransactionMapper.updateStatusById(id, status);
		if (ret != 1) {
			throw new Exception();
		}
	}

}
