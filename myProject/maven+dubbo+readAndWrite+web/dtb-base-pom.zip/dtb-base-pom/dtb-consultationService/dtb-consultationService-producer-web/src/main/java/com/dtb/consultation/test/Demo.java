package com.dtb.consultation.test;

import com.dtb.common.annotation.AnnotationConfiguration;

public class Demo {
	public static void main(String[] args) {
		AnnotationConfiguration an = new AnnotationConfiguration("com.dtb.consultation.serviceImpl");
		System.out.println(an.getProducerMaps());
	}
}
