package com.dtb.common.annotation;


import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.jms.connection.JmsTransactionManager;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
/**
 * 初始化注解加载器-请配置ioc
 * @author xuecheng
 *
 */
public class AnnotationConfiguration{
	private HashMap<String,ReadOnly> ProducerMaps = null;

	public AnnotationConfiguration(String classPath){
		initConfiguration(classPath);
	}
	
	public HashMap<String, ReadOnly> getProducerMaps() {
		return ProducerMaps;
	}

	public void setProducerMaps(HashMap<String, ReadOnly> producerMaps) {
		ProducerMaps = producerMaps;
	}
	/**
	 * 	初始化注解类
	 * @param classPath
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws SecurityException
	 */
	private void initConfiguration(String classPath){
		/** 获取目标包下面所有的类信息 **/
		List<Class<?>> clazzs = ClassUtil.getClasses(classPath);
		for (Class<?> clazz : clazzs) {
			Method[] methods = clazz.getMethods();
			for (Method method : methods) {
				/**满足携带生产者注解的,初始化生产者**/
				if (method.isAnnotationPresent(ReadOnly.class)) {
					initProducerMaps(clazz,method);
				}
			}
		}
	}
	/**
	 * 初始化生产者注解类信息
	 * @param clazz
	 * @param method
	 */
	private void initProducerMaps(Class<?> clazz,Method method){
		if (ProducerMaps==null) {
			ProducerMaps = new HashMap<String, ReadOnly>();
		}
		/**取出该注解  存入生产者Map中**/
		ReadOnly annotation = method.getAnnotation(ReadOnly.class);
		/**存入 key:serviceImpl 类信息.方法名    value:注解内容**/
		ProducerMaps.put(clazz.getName()+"."+method.getName(), annotation);
	}
}
