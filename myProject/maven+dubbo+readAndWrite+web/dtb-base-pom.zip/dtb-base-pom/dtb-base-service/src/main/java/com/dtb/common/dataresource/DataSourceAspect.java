package com.dtb.common.dataresource;
import java.util.HashMap;
import java.util.UUID;

import org.aspectj.lang.JoinPoint;
import org.springframework.beans.factory.annotation.Autowired;

import com.dtb.common.annotation.AnnotationConfiguration;
import com.dtb.common.annotation.ReadOnly;
 
/**
 * 定义数据源的AOP切面，通过该Service的方法名判断是应该走读库还是写库
 *
 */
public class DataSourceAspect {
	@Autowired
	private AnnotationConfiguration annotationConfiguration;
    /**
     * 在进入Service方法之前执行
     *
     * @param point 切面对象
     */
    public void before(JoinPoint point) {
        // 判断当前方法是否具有readOnly注解
    	boolean readOnly = isReadOnly(point);
        if (readOnly) {
            // 标记为读库
            DynamicDataSourceHolder.markSlave();
        } else {
            // 标记为写库
            DynamicDataSourceHolder.markMaster();
        }
    }
    /**
	 * 处理生产者私有方法
	 * 
	 * @param point
	 * @return
	 * @throws MustSignProducerException 
	 * @throws DisTransactionNotResultException
	 */
	private boolean isReadOnly(JoinPoint point){
		String methodAddress = point.toString();
		String method = methodAddress.substring(methodAddress.lastIndexOf("."), methodAddress.lastIndexOf("("));
		String methodPath = point.getTarget().toString().substring(0, point.getTarget().toString().lastIndexOf("@"))+ method;
		HashMap<String, ReadOnly> annotationMaps = annotationConfiguration.getProducerMaps();
		if (annotationMaps != null) {
			if (annotationMaps.containsKey(methodPath)) {/** 初始化开启分布式事务 **/
				return true;
			}
		}
		return false;
	}
    /**
     * 判断是否为读库
     *
     * @param methodName
     * @return
     */
    private Boolean isSlave(String methodName) {
        // 方法名以query、find、get开头的方法名走从库
    	if (methodName.startsWith("query")||methodName.startsWith("find")||methodName.startsWith("get")||methodName.startsWith("select")) {
			return true;
		}
        return false;
    }
}