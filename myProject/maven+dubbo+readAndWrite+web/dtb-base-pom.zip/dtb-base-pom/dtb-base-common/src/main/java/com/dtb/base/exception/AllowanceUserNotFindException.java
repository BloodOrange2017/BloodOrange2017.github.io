package com.dtb.base.exception;

public class AllowanceUserNotFindException extends UserAssertException{
	public AllowanceUserNotFindException() {
		super("EXCEPTION:补贴用户不存在",null);
	}
	public AllowanceUserNotFindException(Object object) {
		super("EXCEPTION:补贴用户不存在!",object);
	}


}
