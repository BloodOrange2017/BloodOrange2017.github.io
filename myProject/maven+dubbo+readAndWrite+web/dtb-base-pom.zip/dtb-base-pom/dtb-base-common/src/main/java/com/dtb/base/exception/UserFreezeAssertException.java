package com.dtb.base.exception;

public class UserFreezeAssertException extends UserAssertException{
	public UserFreezeAssertException() {
		super("EXCEPTION: 用户冻结资产处理发生异常!",null);
	}
	public UserFreezeAssertException(Object object) {
		super("EXCEPTION: 用户冻结资产处理发生异常!",object);
	}
	public UserFreezeAssertException(String string, Object object) {
		super(string,object);
	}

}
