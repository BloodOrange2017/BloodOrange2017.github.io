package com.dtb.base.exception;

import java.util.Date;

/**
 * 
 * @author xuecheng
 *
 */
public class ExceptionLoger {
	String message;
	String content;
	Date insertTime;
	Object params;
	boolean openFile;
	boolean openDataBase;
	boolean openEmail;
	
	
	public ExceptionLoger(String message, String content, Date insertTime, Object params, boolean openFile,
			boolean openDataBase, boolean openEmail) {
		super();
		this.message = message;
		this.content = content;
		this.insertTime = insertTime;
		this.params = params;
		this.openFile = openFile;
		this.openDataBase = openDataBase;
		this.openEmail = openEmail;
	}
	public ExceptionLoger() {
		// TODO Auto-generated constructor stub
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean getOpenFile() {
		return openFile;
	}
	public void setOpenFile(boolean openFile) {
		this.openFile = openFile;
	}
	public boolean getOpenDataBase() {
		return openDataBase;
	}
	public void setOpenDataBase(boolean openDataBase) {
		this.openDataBase = openDataBase;
	}
	public boolean getOpenEmail() {
		return openEmail;
	}
	public void setOpenEmail(boolean openEmail) {
		this.openEmail = openEmail;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getInsertTime() {
		return insertTime;
	}
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}
	public Object getParams() {
		return params;
	}
	
	
	@Override
	public String toString() {
		return "ExceptionLoger [message=" + message + ", content=" + content + ", insertTime=" + insertTime
				+ ", params=" + params + ", openFile=" + openFile + ", openDataBase=" + openDataBase + ", openEmail="
				+ openEmail + "]";
	}
	public void setParams(Object params) {
		this.params = params;
	}
	
}
