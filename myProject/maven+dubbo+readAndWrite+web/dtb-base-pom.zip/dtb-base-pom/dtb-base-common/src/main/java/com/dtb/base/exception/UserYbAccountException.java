package com.dtb.base.exception;

public class UserYbAccountException extends UserAssertException{
	public UserYbAccountException() {
		super("EXCEPTION: 用户易宝资产操作出现异常！",null);
	}
	public UserYbAccountException(Object object) {
		super("EXCEPTION: 用户易宝资产操作出现异常！",object);
	}
	public UserYbAccountException(String string, Object object) {
		super(string,object);
	}

}
