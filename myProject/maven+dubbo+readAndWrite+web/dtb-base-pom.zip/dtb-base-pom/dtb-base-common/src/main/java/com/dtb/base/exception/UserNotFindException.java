package com.dtb.base.exception;

public class UserNotFindException extends CustomException{
	public UserNotFindException() {
		super("EXCEPTION: 没有查询到该用户!",null);
	}
	public UserNotFindException(Object object) {
		super("EXCEPTION: 没有查询到该用户!",object);
	}
	public UserNotFindException(String string, Object object) {
		super(string,object);
	}
	public UserNotFindException(String string, Object object, Exception e) {
		super(string,object,e);
	}
}
