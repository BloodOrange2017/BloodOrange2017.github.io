package com.dtb.base.exception;

public class ServiceUserNotFindException extends UserNotFindException{
	public ServiceUserNotFindException() {
		super("EXCEPTION: 服务商用户不存在!",null);
	}
	public ServiceUserNotFindException(Object object) {
		super("EXCEPTION: 服务商用户不存在!",object);
	}


}
