package com.dtb.consultation.mapper;

import com.dtb.consultation.entity.User;

public interface ConsultationMapper {

	User selectUserByMobile(String mobile);

	void testUpdate(String mobile);

}
