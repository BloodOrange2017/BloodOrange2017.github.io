package com.dtb.consultation.service;

import com.dtb.consultation.entity.User;

public interface ConsultationService {
	void show(String message);
	
	User selectUser(String mobile);
	
	void TestTransaction(String mobile) throws Exception;
}
