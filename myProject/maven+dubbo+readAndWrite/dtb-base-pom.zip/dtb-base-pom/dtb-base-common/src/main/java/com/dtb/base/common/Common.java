package com.dtb.base.common;

public class Common {

}
